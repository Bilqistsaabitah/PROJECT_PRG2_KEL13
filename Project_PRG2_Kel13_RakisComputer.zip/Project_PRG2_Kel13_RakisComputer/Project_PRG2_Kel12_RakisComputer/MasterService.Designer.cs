﻿namespace Project_PRG2_Kel12_RakisComputer
{
    partial class MasterService
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MasterService));
            this.label1 = new System.Windows.Forms.Label();
            this.btnTtgAplikasi = new System.Windows.Forms.Label();
            this.bunifuCustomDataGrid1 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.idServiceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.namaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tglServiceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.deskripsiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serviceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.db_Rakis_computerrDataSet = new Project_PRG2_Kel12_RakisComputer.db_Rakis_computerrDataSet();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnMember = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnLogout = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnDashboard = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnSegarkan = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnTmbhData = new Bunifu.Framework.UI.BunifuThinButton2();
            this.serviceTableAdapter = new Project_PRG2_Kel12_RakisComputer.db_Rakis_computerrDataSetTableAdapters.ServiceTableAdapter();
            this.BtnClose = new Bunifu.Framework.UI.BunifuImageButton();
            this.btnPegawai = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnProduk = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnJenisProduk = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnDistributor = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnPaket = new Bunifu.Framework.UI.BunifuFlatButton();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.serviceBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.db_Rakis_computerrDataSet)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnClose)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label1.Location = new System.Drawing.Point(13, 951);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(324, 19);
            this.label1.TabIndex = 12;
            this.label1.Text = "Bilqis Tsaabitah && Ramadhan Dewantara";
            // 
            // btnTtgAplikasi
            // 
            this.btnTtgAplikasi.AutoSize = true;
            this.btnTtgAplikasi.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTtgAplikasi.ForeColor = System.Drawing.Color.SaddleBrown;
            this.btnTtgAplikasi.Location = new System.Drawing.Point(105, 920);
            this.btnTtgAplikasi.Name = "btnTtgAplikasi";
            this.btnTtgAplikasi.Size = new System.Drawing.Size(153, 22);
            this.btnTtgAplikasi.TabIndex = 4;
            this.btnTtgAplikasi.Text = "Tentang Aplikasi";
            this.btnTtgAplikasi.Click += new System.EventHandler(this.btnTtgAplikasi_Click);
            // 
            // bunifuCustomDataGrid1
            // 
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuCustomDataGrid1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle33;
            this.bunifuCustomDataGrid1.AutoGenerateColumns = false;
            this.bunifuCustomDataGrid1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.bunifuCustomDataGrid1.BackgroundColor = System.Drawing.Color.MistyRose;
            this.bunifuCustomDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuCustomDataGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle34.BackColor = System.Drawing.Color.RosyBrown;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.Color.MistyRose;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuCustomDataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle34;
            this.bunifuCustomDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bunifuCustomDataGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idServiceDataGridViewTextBoxColumn,
            this.namaDataGridViewTextBoxColumn,
            this.tglServiceDataGridViewTextBoxColumn,
            this.deskripsiDataGridViewTextBoxColumn});
            this.bunifuCustomDataGrid1.DataSource = this.serviceBindingSource;
            this.bunifuCustomDataGrid1.DoubleBuffered = true;
            this.bunifuCustomDataGrid1.EnableHeadersVisualStyles = false;
            this.bunifuCustomDataGrid1.GridColor = System.Drawing.Color.MistyRose;
            this.bunifuCustomDataGrid1.HeaderBgColor = System.Drawing.Color.RosyBrown;
            this.bunifuCustomDataGrid1.HeaderForeColor = System.Drawing.Color.MistyRose;
            this.bunifuCustomDataGrid1.Location = new System.Drawing.Point(572, 229);
            this.bunifuCustomDataGrid1.Name = "bunifuCustomDataGrid1";
            this.bunifuCustomDataGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.bunifuCustomDataGrid1.RowTemplate.Height = 28;
            this.bunifuCustomDataGrid1.Size = new System.Drawing.Size(1226, 672);
            this.bunifuCustomDataGrid1.TabIndex = 45;
            // 
            // idServiceDataGridViewTextBoxColumn
            // 
            this.idServiceDataGridViewTextBoxColumn.DataPropertyName = "Id_Service";
            this.idServiceDataGridViewTextBoxColumn.HeaderText = "Id_Service";
            this.idServiceDataGridViewTextBoxColumn.Name = "idServiceDataGridViewTextBoxColumn";
            // 
            // namaDataGridViewTextBoxColumn
            // 
            this.namaDataGridViewTextBoxColumn.DataPropertyName = "nama";
            this.namaDataGridViewTextBoxColumn.HeaderText = "nama";
            this.namaDataGridViewTextBoxColumn.Name = "namaDataGridViewTextBoxColumn";
            // 
            // tglServiceDataGridViewTextBoxColumn
            // 
            this.tglServiceDataGridViewTextBoxColumn.DataPropertyName = "tgl_Service";
            this.tglServiceDataGridViewTextBoxColumn.HeaderText = "tgl_Service";
            this.tglServiceDataGridViewTextBoxColumn.Name = "tglServiceDataGridViewTextBoxColumn";
            // 
            // deskripsiDataGridViewTextBoxColumn
            // 
            this.deskripsiDataGridViewTextBoxColumn.DataPropertyName = "Deskripsi";
            this.deskripsiDataGridViewTextBoxColumn.HeaderText = "Deskripsi";
            this.deskripsiDataGridViewTextBoxColumn.Name = "deskripsiDataGridViewTextBoxColumn";
            // 
            // serviceBindingSource
            // 
            this.serviceBindingSource.DataMember = "Service";
            this.serviceBindingSource.DataSource = this.db_Rakis_computerrDataSet;
            // 
            // db_Rakis_computerrDataSet
            // 
            this.db_Rakis_computerrDataSet.DataSetName = "db_Rakis_computerrDataSet";
            this.db_Rakis_computerrDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label2.Location = new System.Drawing.Point(994, 134);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(493, 56);
            this.label2.TabIndex = 44;
            this.label2.Text = "TABEL DATA SERVICE";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Tan;
            this.panel2.Controls.Add(this.BtnClose);
            this.panel2.Controls.Add(this.bunifuImageButton1);
            this.panel2.Controls.Add(this.bunifuCustomLabel1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1898, 49);
            this.panel2.TabIndex = 43;
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton1.Image = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_reboot_30px;
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(1718, -2);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(80, 48);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton1.TabIndex = 48;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            this.bunifuImageButton1.Click += new System.EventHandler(this.bunifuImageButton1_Click);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.SaddleBrown;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(11, 9);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(706, 28);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "Aplikasi Rakis Computer - Halaman Admin - Master Service";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.RosyBrown;
            this.panel1.Controls.Add(this.btnPaket);
            this.panel1.Controls.Add(this.bunifuFlatButton2);
            this.panel1.Controls.Add(this.bunifuFlatButton1);
            this.panel1.Controls.Add(this.btnDistributor);
            this.panel1.Controls.Add(this.btnJenisProduk);
            this.panel1.Controls.Add(this.btnProduk);
            this.panel1.Controls.Add(this.btnPegawai);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnTtgAplikasi);
            this.panel1.Controls.Add(this.btnMember);
            this.panel1.Controls.Add(this.btnLogout);
            this.panel1.Controls.Add(this.btnDashboard);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.ForeColor = System.Drawing.Color.RosyBrown;
            this.panel1.Location = new System.Drawing.Point(-1, 45);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(363, 1000);
            this.panel1.TabIndex = 42;
            // 
            // btnMember
            // 
            this.btnMember.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnMember.BackColor = System.Drawing.Color.RosyBrown;
            this.btnMember.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMember.BorderRadius = 0;
            this.btnMember.ButtonText = "Member";
            this.btnMember.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMember.DisabledColor = System.Drawing.Color.Black;
            this.btnMember.Iconcolor = System.Drawing.Color.Transparent;
            this.btnMember.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_name_tag_64;
            this.btnMember.Iconimage_right = null;
            this.btnMember.Iconimage_right_Selected = null;
            this.btnMember.Iconimage_Selected = null;
            this.btnMember.IconMarginLeft = 0;
            this.btnMember.IconMarginRight = 0;
            this.btnMember.IconRightVisible = true;
            this.btnMember.IconRightZoom = 0D;
            this.btnMember.IconVisible = true;
            this.btnMember.IconZoom = 90D;
            this.btnMember.IsTab = false;
            this.btnMember.Location = new System.Drawing.Point(0, 348);
            this.btnMember.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnMember.Name = "btnMember";
            this.btnMember.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnMember.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnMember.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnMember.selected = false;
            this.btnMember.Size = new System.Drawing.Size(362, 74);
            this.btnMember.TabIndex = 11;
            this.btnMember.Text = "Member";
            this.btnMember.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnMember.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnMember.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMember.Click += new System.EventHandler(this.btnMember_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnLogout.BackColor = System.Drawing.Color.RosyBrown;
            this.btnLogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLogout.BorderRadius = 0;
            this.btnLogout.ButtonText = "Logout";
            this.btnLogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogout.DisabledColor = System.Drawing.Color.Black;
            this.btnLogout.Iconcolor = System.Drawing.Color.Transparent;
            this.btnLogout.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_exit_30px;
            this.btnLogout.Iconimage_right = null;
            this.btnLogout.Iconimage_right_Selected = null;
            this.btnLogout.Iconimage_Selected = null;
            this.btnLogout.IconMarginLeft = 0;
            this.btnLogout.IconMarginRight = 0;
            this.btnLogout.IconRightVisible = true;
            this.btnLogout.IconRightZoom = 0D;
            this.btnLogout.IconVisible = true;
            this.btnLogout.IconZoom = 90D;
            this.btnLogout.IsTab = false;
            this.btnLogout.Location = new System.Drawing.Point(-3, 810);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnLogout.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnLogout.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnLogout.selected = false;
            this.btnLogout.Size = new System.Drawing.Size(362, 74);
            this.btnLogout.TabIndex = 7;
            this.btnLogout.Text = "Logout";
            this.btnLogout.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnLogout.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnLogout.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnDashboard
            // 
            this.btnDashboard.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnDashboard.BackColor = System.Drawing.Color.RosyBrown;
            this.btnDashboard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDashboard.BorderRadius = 0;
            this.btnDashboard.ButtonText = "Dashboard";
            this.btnDashboard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDashboard.DisabledColor = System.Drawing.Color.Black;
            this.btnDashboard.Iconcolor = System.Drawing.Color.Transparent;
            this.btnDashboard.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_home_30px_1;
            this.btnDashboard.Iconimage_right = null;
            this.btnDashboard.Iconimage_right_Selected = null;
            this.btnDashboard.Iconimage_Selected = null;
            this.btnDashboard.IconMarginLeft = 0;
            this.btnDashboard.IconMarginRight = 0;
            this.btnDashboard.IconRightVisible = true;
            this.btnDashboard.IconRightZoom = 0D;
            this.btnDashboard.IconVisible = true;
            this.btnDashboard.IconZoom = 90D;
            this.btnDashboard.IsTab = false;
            this.btnDashboard.Location = new System.Drawing.Point(-3, 221);
            this.btnDashboard.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnDashboard.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnDashboard.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnDashboard.selected = false;
            this.btnDashboard.Size = new System.Drawing.Size(362, 74);
            this.btnDashboard.TabIndex = 1;
            this.btnDashboard.Text = "Dashboard";
            this.btnDashboard.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDashboard.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnDashboard.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.Kebawah;
            this.pictureBox1.Location = new System.Drawing.Point(-74, -99);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(477, 474);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnSegarkan
            // 
            this.btnSegarkan.ActiveBorderThickness = 1;
            this.btnSegarkan.ActiveCornerRadius = 20;
            this.btnSegarkan.ActiveFillColor = System.Drawing.Color.Transparent;
            this.btnSegarkan.ActiveForecolor = System.Drawing.Color.RosyBrown;
            this.btnSegarkan.ActiveLineColor = System.Drawing.Color.Black;
            this.btnSegarkan.BackColor = System.Drawing.Color.MistyRose;
            this.btnSegarkan.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSegarkan.BackgroundImage")));
            this.btnSegarkan.ButtonText = "Ubah Data";
            this.btnSegarkan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSegarkan.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSegarkan.ForeColor = System.Drawing.Color.SaddleBrown;
            this.btnSegarkan.IdleBorderThickness = 1;
            this.btnSegarkan.IdleCornerRadius = 20;
            this.btnSegarkan.IdleFillColor = System.Drawing.Color.MistyRose;
            this.btnSegarkan.IdleForecolor = System.Drawing.Color.SaddleBrown;
            this.btnSegarkan.IdleLineColor = System.Drawing.Color.SaddleBrown;
            this.btnSegarkan.Location = new System.Drawing.Point(1365, 924);
            this.btnSegarkan.Margin = new System.Windows.Forms.Padding(5);
            this.btnSegarkan.Name = "btnSegarkan";
            this.btnSegarkan.Size = new System.Drawing.Size(243, 63);
            this.btnSegarkan.TabIndex = 47;
            this.btnSegarkan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSegarkan.Click += new System.EventHandler(this.btnSegarkan_Click);
            // 
            // btnTmbhData
            // 
            this.btnTmbhData.ActiveBorderThickness = 1;
            this.btnTmbhData.ActiveCornerRadius = 20;
            this.btnTmbhData.ActiveFillColor = System.Drawing.Color.Transparent;
            this.btnTmbhData.ActiveForecolor = System.Drawing.Color.RosyBrown;
            this.btnTmbhData.ActiveLineColor = System.Drawing.Color.Black;
            this.btnTmbhData.BackColor = System.Drawing.Color.MistyRose;
            this.btnTmbhData.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnTmbhData.BackgroundImage")));
            this.btnTmbhData.ButtonText = "Tambah Data";
            this.btnTmbhData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTmbhData.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTmbhData.ForeColor = System.Drawing.Color.SaddleBrown;
            this.btnTmbhData.IdleBorderThickness = 1;
            this.btnTmbhData.IdleCornerRadius = 20;
            this.btnTmbhData.IdleFillColor = System.Drawing.Color.MistyRose;
            this.btnTmbhData.IdleForecolor = System.Drawing.Color.SaddleBrown;
            this.btnTmbhData.IdleLineColor = System.Drawing.Color.SaddleBrown;
            this.btnTmbhData.Location = new System.Drawing.Point(847, 924);
            this.btnTmbhData.Margin = new System.Windows.Forms.Padding(5);
            this.btnTmbhData.Name = "btnTmbhData";
            this.btnTmbhData.Size = new System.Drawing.Size(243, 63);
            this.btnTmbhData.TabIndex = 46;
            this.btnTmbhData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnTmbhData.Click += new System.EventHandler(this.btnTmbhData_Click);
            // 
            // serviceTableAdapter
            // 
            this.serviceTableAdapter.ClearBeforeFill = true;
            // 
            // BtnClose
            // 
            this.BtnClose.BackColor = System.Drawing.Color.Transparent;
            this.BtnClose.Image = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_delete_30px;
            this.BtnClose.ImageActive = null;
            this.BtnClose.Location = new System.Drawing.Point(1850, -2);
            this.BtnClose.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(48, 51);
            this.BtnClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BtnClose.TabIndex = 48;
            this.BtnClose.TabStop = false;
            this.BtnClose.Zoom = 10;
            this.BtnClose.Click += new System.EventHandler(this.BtnClose_Click);
            // 
            // btnPegawai
            // 
            this.btnPegawai.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnPegawai.BackColor = System.Drawing.Color.RosyBrown;
            this.btnPegawai.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPegawai.BorderRadius = 0;
            this.btnPegawai.ButtonText = "Employee";
            this.btnPegawai.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPegawai.DisabledColor = System.Drawing.Color.Black;
            this.btnPegawai.Iconcolor = System.Drawing.Color.Transparent;
            this.btnPegawai.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_exit_30px;
            this.btnPegawai.Iconimage_right = null;
            this.btnPegawai.Iconimage_right_Selected = null;
            this.btnPegawai.Iconimage_Selected = null;
            this.btnPegawai.IconMarginLeft = 0;
            this.btnPegawai.IconMarginRight = 0;
            this.btnPegawai.IconRightVisible = true;
            this.btnPegawai.IconRightZoom = 0D;
            this.btnPegawai.IconVisible = true;
            this.btnPegawai.IconZoom = 90D;
            this.btnPegawai.IsTab = false;
            this.btnPegawai.Location = new System.Drawing.Point(0, 285);
            this.btnPegawai.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPegawai.Name = "btnPegawai";
            this.btnPegawai.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnPegawai.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnPegawai.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnPegawai.selected = false;
            this.btnPegawai.Size = new System.Drawing.Size(362, 75);
            this.btnPegawai.TabIndex = 48;
            this.btnPegawai.Text = "Employee";
            this.btnPegawai.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnPegawai.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnPegawai.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPegawai.Click += new System.EventHandler(this.btnPegawai_Click);
            // 
            // btnProduk
            // 
            this.btnProduk.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnProduk.BackColor = System.Drawing.Color.RosyBrown;
            this.btnProduk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnProduk.BorderRadius = 0;
            this.btnProduk.ButtonText = "Product";
            this.btnProduk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProduk.DisabledColor = System.Drawing.Color.Black;
            this.btnProduk.Iconcolor = System.Drawing.Color.Transparent;
            this.btnProduk.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_shopping_basket_30px;
            this.btnProduk.Iconimage_right = null;
            this.btnProduk.Iconimage_right_Selected = null;
            this.btnProduk.Iconimage_Selected = null;
            this.btnProduk.IconMarginLeft = 0;
            this.btnProduk.IconMarginRight = 0;
            this.btnProduk.IconRightVisible = true;
            this.btnProduk.IconRightZoom = 0D;
            this.btnProduk.IconVisible = true;
            this.btnProduk.IconZoom = 90D;
            this.btnProduk.IsTab = false;
            this.btnProduk.Location = new System.Drawing.Point(1, 410);
            this.btnProduk.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnProduk.Name = "btnProduk";
            this.btnProduk.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnProduk.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnProduk.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnProduk.selected = false;
            this.btnProduk.Size = new System.Drawing.Size(362, 74);
            this.btnProduk.TabIndex = 49;
            this.btnProduk.Text = "Product";
            this.btnProduk.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnProduk.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnProduk.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProduk.Click += new System.EventHandler(this.btnProduk_Click);
            // 
            // btnJenisProduk
            // 
            this.btnJenisProduk.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnJenisProduk.BackColor = System.Drawing.Color.RosyBrown;
            this.btnJenisProduk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnJenisProduk.BorderRadius = 0;
            this.btnJenisProduk.ButtonText = "Jenis Product";
            this.btnJenisProduk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnJenisProduk.DisabledColor = System.Drawing.Color.Black;
            this.btnJenisProduk.Iconcolor = System.Drawing.Color.Transparent;
            this.btnJenisProduk.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_tasks_30px;
            this.btnJenisProduk.Iconimage_right = null;
            this.btnJenisProduk.Iconimage_right_Selected = null;
            this.btnJenisProduk.Iconimage_Selected = null;
            this.btnJenisProduk.IconMarginLeft = 0;
            this.btnJenisProduk.IconMarginRight = 0;
            this.btnJenisProduk.IconRightVisible = true;
            this.btnJenisProduk.IconRightZoom = 0D;
            this.btnJenisProduk.IconVisible = true;
            this.btnJenisProduk.IconZoom = 90D;
            this.btnJenisProduk.IsTab = false;
            this.btnJenisProduk.Location = new System.Drawing.Point(1, 473);
            this.btnJenisProduk.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnJenisProduk.Name = "btnJenisProduk";
            this.btnJenisProduk.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnJenisProduk.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnJenisProduk.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnJenisProduk.selected = false;
            this.btnJenisProduk.Size = new System.Drawing.Size(362, 74);
            this.btnJenisProduk.TabIndex = 50;
            this.btnJenisProduk.Text = "Jenis Product";
            this.btnJenisProduk.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnJenisProduk.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnJenisProduk.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJenisProduk.Click += new System.EventHandler(this.btnJenisProduk_Click);
            // 
            // btnDistributor
            // 
            this.btnDistributor.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnDistributor.BackColor = System.Drawing.Color.RosyBrown;
            this.btnDistributor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDistributor.BorderRadius = 0;
            this.btnDistributor.ButtonText = "Distributor";
            this.btnDistributor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDistributor.DisabledColor = System.Drawing.Color.Black;
            this.btnDistributor.Iconcolor = System.Drawing.Color.Transparent;
            this.btnDistributor.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_shopping_bag_30px;
            this.btnDistributor.Iconimage_right = null;
            this.btnDistributor.Iconimage_right_Selected = null;
            this.btnDistributor.Iconimage_Selected = null;
            this.btnDistributor.IconMarginLeft = 0;
            this.btnDistributor.IconMarginRight = 0;
            this.btnDistributor.IconRightVisible = true;
            this.btnDistributor.IconRightZoom = 0D;
            this.btnDistributor.IconVisible = true;
            this.btnDistributor.IconZoom = 90D;
            this.btnDistributor.IsTab = false;
            this.btnDistributor.Location = new System.Drawing.Point(1, 539);
            this.btnDistributor.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDistributor.Name = "btnDistributor";
            this.btnDistributor.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnDistributor.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnDistributor.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnDistributor.selected = false;
            this.btnDistributor.Size = new System.Drawing.Size(362, 74);
            this.btnDistributor.TabIndex = 51;
            this.btnDistributor.Text = "Distributor";
            this.btnDistributor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDistributor.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnDistributor.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDistributor.Click += new System.EventHandler(this.btnDistributor_Click);
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.RosyBrown;
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.RosyBrown;
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "Purchasing Order";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Black;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_checkout_30px_2;
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(0, 602);
            this.bunifuFlatButton1.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.RosyBrown;
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.MistyRose;
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.Black;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(362, 74);
            this.bunifuFlatButton1.TabIndex = 52;
            this.bunifuFlatButton1.Text = "Purchasing Order";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.SaddleBrown;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // bunifuFlatButton2
            // 
            this.bunifuFlatButton2.Activecolor = System.Drawing.Color.RosyBrown;
            this.bunifuFlatButton2.BackColor = System.Drawing.Color.RosyBrown;
            this.bunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton2.BorderRadius = 0;
            this.bunifuFlatButton2.ButtonText = "Service";
            this.bunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton2.DisabledColor = System.Drawing.Color.Black;
            this.bunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_maintenance_30px;
            this.bunifuFlatButton2.Iconimage_right = null;
            this.bunifuFlatButton2.Iconimage_right_Selected = null;
            this.bunifuFlatButton2.Iconimage_Selected = null;
            this.bunifuFlatButton2.IconMarginLeft = 0;
            this.bunifuFlatButton2.IconMarginRight = 0;
            this.bunifuFlatButton2.IconRightVisible = true;
            this.bunifuFlatButton2.IconRightZoom = 0D;
            this.bunifuFlatButton2.IconVisible = true;
            this.bunifuFlatButton2.IconZoom = 90D;
            this.bunifuFlatButton2.IsTab = false;
            this.bunifuFlatButton2.Location = new System.Drawing.Point(1, 668);
            this.bunifuFlatButton2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bunifuFlatButton2.Name = "bunifuFlatButton2";
            this.bunifuFlatButton2.Normalcolor = System.Drawing.Color.RosyBrown;
            this.bunifuFlatButton2.OnHovercolor = System.Drawing.Color.MistyRose;
            this.bunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.Black;
            this.bunifuFlatButton2.selected = false;
            this.bunifuFlatButton2.Size = new System.Drawing.Size(371, 74);
            this.bunifuFlatButton2.TabIndex = 53;
            this.bunifuFlatButton2.Text = "Service";
            this.bunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton2.Textcolor = System.Drawing.Color.SaddleBrown;
            this.bunifuFlatButton2.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton2.Click += new System.EventHandler(this.bunifuFlatButton2_Click);
            // 
            // btnPaket
            // 
            this.btnPaket.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnPaket.BackColor = System.Drawing.Color.RosyBrown;
            this.btnPaket.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPaket.BorderRadius = 0;
            this.btnPaket.ButtonText = "Paket";
            this.btnPaket.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPaket.DisabledColor = System.Drawing.Color.Black;
            this.btnPaket.Iconcolor = System.Drawing.Color.Transparent;
            this.btnPaket.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_new_job_30px;
            this.btnPaket.Iconimage_right = null;
            this.btnPaket.Iconimage_right_Selected = null;
            this.btnPaket.Iconimage_Selected = null;
            this.btnPaket.IconMarginLeft = 0;
            this.btnPaket.IconMarginRight = 0;
            this.btnPaket.IconRightVisible = true;
            this.btnPaket.IconRightZoom = 0D;
            this.btnPaket.IconVisible = true;
            this.btnPaket.IconZoom = 90D;
            this.btnPaket.IsTab = false;
            this.btnPaket.Location = new System.Drawing.Point(1, 740);
            this.btnPaket.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPaket.Name = "btnPaket";
            this.btnPaket.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnPaket.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnPaket.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnPaket.selected = false;
            this.btnPaket.Size = new System.Drawing.Size(362, 74);
            this.btnPaket.TabIndex = 54;
            this.btnPaket.Text = "Paket";
            this.btnPaket.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnPaket.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnPaket.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPaket.Click += new System.EventHandler(this.btnPaket_Click);
            // 
            // MasterService
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(1898, 1024);
            this.Controls.Add(this.btnSegarkan);
            this.Controls.Add(this.btnTmbhData);
            this.Controls.Add(this.bunifuCustomDataGrid1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "MasterService";
            this.Text = "MasterService";
            this.Load += new System.EventHandler(this.MasterService_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.serviceBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.db_Rakis_computerrDataSet)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnClose)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label btnTtgAplikasi;
        private Bunifu.Framework.UI.BunifuFlatButton btnMember;
        private Bunifu.Framework.UI.BunifuFlatButton btnLogout;
        private Bunifu.Framework.UI.BunifuThinButton2 btnSegarkan;
        private Bunifu.Framework.UI.BunifuThinButton2 btnTmbhData;
        private Bunifu.Framework.UI.BunifuCustomDataGrid bunifuCustomDataGrid1;
        private System.Windows.Forms.Label label2;
        private Bunifu.Framework.UI.BunifuFlatButton btnDashboard;
        private System.Windows.Forms.Panel panel2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private db_Rakis_computerrDataSet db_Rakis_computerrDataSet;
        private System.Windows.Forms.BindingSource serviceBindingSource;
        private db_Rakis_computerrDataSetTableAdapters.ServiceTableAdapter serviceTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idServiceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn namaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tglServiceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn deskripsiDataGridViewTextBoxColumn;
        private Bunifu.Framework.UI.BunifuImageButton BtnClose;
        private Bunifu.Framework.UI.BunifuFlatButton btnPegawai;
        private Bunifu.Framework.UI.BunifuFlatButton btnProduk;
        private Bunifu.Framework.UI.BunifuFlatButton btnJenisProduk;
        private Bunifu.Framework.UI.BunifuFlatButton btnDistributor;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton2;
        private Bunifu.Framework.UI.BunifuFlatButton btnPaket;
    }
}