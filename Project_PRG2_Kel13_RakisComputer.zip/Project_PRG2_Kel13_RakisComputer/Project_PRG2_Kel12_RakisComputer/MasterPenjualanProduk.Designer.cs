﻿namespace Project_PRG2_Kel12_RakisComputer
{
    partial class MasterPenjualanProduk
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MasterPenjualanProduk));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.btnPO = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label1 = new System.Windows.Forms.Label();
            this.btnTtgAplikasi = new System.Windows.Forms.Label();
            this.btnMember = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnService = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnPenjualanProduk = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnLogout = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnSegarkan = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnTmbhData = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuCustomDataGrid1 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.label2 = new System.Windows.Forms.Label();
            this.btnDashboard = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuCustomDataGrid2 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.panel4 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid2)).BeginInit();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.RosyBrown;
            this.panel1.ForeColor = System.Drawing.Color.RosyBrown;
            this.panel1.Location = new System.Drawing.Point(-1, 45);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(354, 946);
            this.panel1.TabIndex = 27;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label3.Location = new System.Drawing.Point(984, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(521, 28);
            this.label3.TabIndex = 49;
            this.label3.Text = "TABEL DATA TRANSAKSI PENJUALAN PRODUK";
            // 
            // btnPO
            // 
            this.btnPO.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnPO.BackColor = System.Drawing.Color.RosyBrown;
            this.btnPO.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPO.BorderRadius = 0;
            this.btnPO.ButtonText = "Purchasing Order";
            this.btnPO.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPO.DisabledColor = System.Drawing.Color.Black;
            this.btnPO.Iconcolor = System.Drawing.Color.Transparent;
            this.btnPO.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_checkout_30px_2;
            this.btnPO.Iconimage_right = null;
            this.btnPO.Iconimage_right_Selected = null;
            this.btnPO.Iconimage_Selected = null;
            this.btnPO.IconMarginLeft = 0;
            this.btnPO.IconMarginRight = 0;
            this.btnPO.IconRightVisible = true;
            this.btnPO.IconRightZoom = 0D;
            this.btnPO.IconVisible = true;
            this.btnPO.IconZoom = 90D;
            this.btnPO.IsTab = false;
            this.btnPO.Location = new System.Drawing.Point(4, 560);
            this.btnPO.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPO.Name = "btnPO";
            this.btnPO.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnPO.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnPO.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnPO.selected = false;
            this.btnPO.Size = new System.Drawing.Size(362, 74);
            this.btnPO.TabIndex = 13;
            this.btnPO.Text = "Purchasing Order";
            this.btnPO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnPO.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnPO.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label1.Location = new System.Drawing.Point(13, 879);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(324, 19);
            this.label1.TabIndex = 12;
            this.label1.Text = "Bilqis Tsaabitah && Ramadhan Dewantara";
            // 
            // btnTtgAplikasi
            // 
            this.btnTtgAplikasi.AutoSize = true;
            this.btnTtgAplikasi.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTtgAplikasi.ForeColor = System.Drawing.Color.SaddleBrown;
            this.btnTtgAplikasi.Location = new System.Drawing.Point(100, 825);
            this.btnTtgAplikasi.Name = "btnTtgAplikasi";
            this.btnTtgAplikasi.Size = new System.Drawing.Size(153, 22);
            this.btnTtgAplikasi.TabIndex = 4;
            this.btnTtgAplikasi.Text = "Tentang Aplikasi";
            // 
            // btnMember
            // 
            this.btnMember.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnMember.BackColor = System.Drawing.Color.RosyBrown;
            this.btnMember.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMember.BorderRadius = 0;
            this.btnMember.ButtonText = "Member";
            this.btnMember.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMember.DisabledColor = System.Drawing.Color.Black;
            this.btnMember.Iconcolor = System.Drawing.Color.Transparent;
            this.btnMember.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_name_tag_64;
            this.btnMember.Iconimage_right = null;
            this.btnMember.Iconimage_right_Selected = null;
            this.btnMember.Iconimage_Selected = null;
            this.btnMember.IconMarginLeft = 0;
            this.btnMember.IconMarginRight = 0;
            this.btnMember.IconRightVisible = true;
            this.btnMember.IconRightZoom = 0D;
            this.btnMember.IconVisible = true;
            this.btnMember.IconZoom = 90D;
            this.btnMember.IsTab = false;
            this.btnMember.Location = new System.Drawing.Point(1, 344);
            this.btnMember.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnMember.Name = "btnMember";
            this.btnMember.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnMember.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnMember.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnMember.selected = false;
            this.btnMember.Size = new System.Drawing.Size(362, 74);
            this.btnMember.TabIndex = 11;
            this.btnMember.Text = "Member";
            this.btnMember.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnMember.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnMember.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnService
            // 
            this.btnService.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnService.BackColor = System.Drawing.Color.RosyBrown;
            this.btnService.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnService.BorderRadius = 0;
            this.btnService.ButtonText = "Service";
            this.btnService.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnService.DisabledColor = System.Drawing.Color.Black;
            this.btnService.Iconcolor = System.Drawing.Color.Transparent;
            this.btnService.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_maintenance_30px;
            this.btnService.Iconimage_right = null;
            this.btnService.Iconimage_right_Selected = null;
            this.btnService.Iconimage_Selected = null;
            this.btnService.IconMarginLeft = 0;
            this.btnService.IconMarginRight = 0;
            this.btnService.IconRightVisible = true;
            this.btnService.IconRightZoom = 0D;
            this.btnService.IconVisible = true;
            this.btnService.IconZoom = 90D;
            this.btnService.IsTab = false;
            this.btnService.Location = new System.Drawing.Point(0, 417);
            this.btnService.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnService.Name = "btnService";
            this.btnService.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnService.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnService.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnService.selected = false;
            this.btnService.Size = new System.Drawing.Size(362, 74);
            this.btnService.TabIndex = 10;
            this.btnService.Text = "Service";
            this.btnService.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnService.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnService.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnPenjualanProduk
            // 
            this.btnPenjualanProduk.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnPenjualanProduk.BackColor = System.Drawing.Color.RosyBrown;
            this.btnPenjualanProduk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPenjualanProduk.BorderRadius = 0;
            this.btnPenjualanProduk.ButtonText = "Penjualan Produk";
            this.btnPenjualanProduk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPenjualanProduk.DisabledColor = System.Drawing.Color.Black;
            this.btnPenjualanProduk.Iconcolor = System.Drawing.Color.Transparent;
            this.btnPenjualanProduk.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_tasks_30px;
            this.btnPenjualanProduk.Iconimage_right = null;
            this.btnPenjualanProduk.Iconimage_right_Selected = null;
            this.btnPenjualanProduk.Iconimage_Selected = null;
            this.btnPenjualanProduk.IconMarginLeft = 0;
            this.btnPenjualanProduk.IconMarginRight = 0;
            this.btnPenjualanProduk.IconRightVisible = true;
            this.btnPenjualanProduk.IconRightZoom = 0D;
            this.btnPenjualanProduk.IconVisible = true;
            this.btnPenjualanProduk.IconZoom = 90D;
            this.btnPenjualanProduk.IsTab = false;
            this.btnPenjualanProduk.Location = new System.Drawing.Point(0, 490);
            this.btnPenjualanProduk.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPenjualanProduk.Name = "btnPenjualanProduk";
            this.btnPenjualanProduk.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnPenjualanProduk.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnPenjualanProduk.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnPenjualanProduk.selected = false;
            this.btnPenjualanProduk.Size = new System.Drawing.Size(362, 74);
            this.btnPenjualanProduk.TabIndex = 9;
            this.btnPenjualanProduk.Text = "Penjualan Produk";
            this.btnPenjualanProduk.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnPenjualanProduk.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnPenjualanProduk.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnLogout
            // 
            this.btnLogout.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnLogout.BackColor = System.Drawing.Color.RosyBrown;
            this.btnLogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLogout.BorderRadius = 0;
            this.btnLogout.ButtonText = "Logout";
            this.btnLogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogout.DisabledColor = System.Drawing.Color.Black;
            this.btnLogout.Iconcolor = System.Drawing.Color.Transparent;
            this.btnLogout.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_exit_30px;
            this.btnLogout.Iconimage_right = null;
            this.btnLogout.Iconimage_right_Selected = null;
            this.btnLogout.Iconimage_Selected = null;
            this.btnLogout.IconMarginLeft = 0;
            this.btnLogout.IconMarginRight = 0;
            this.btnLogout.IconRightVisible = true;
            this.btnLogout.IconRightZoom = 0D;
            this.btnLogout.IconVisible = true;
            this.btnLogout.IconZoom = 90D;
            this.btnLogout.IsTab = false;
            this.btnLogout.Location = new System.Drawing.Point(1, 635);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnLogout.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnLogout.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnLogout.selected = false;
            this.btnLogout.Size = new System.Drawing.Size(362, 74);
            this.btnLogout.TabIndex = 7;
            this.btnLogout.Text = "Logout";
            this.btnLogout.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnLogout.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnLogout.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnSegarkan
            // 
            this.btnSegarkan.ActiveBorderThickness = 1;
            this.btnSegarkan.ActiveCornerRadius = 20;
            this.btnSegarkan.ActiveFillColor = System.Drawing.Color.Transparent;
            this.btnSegarkan.ActiveForecolor = System.Drawing.Color.RosyBrown;
            this.btnSegarkan.ActiveLineColor = System.Drawing.Color.Black;
            this.btnSegarkan.BackColor = System.Drawing.Color.MistyRose;
            this.btnSegarkan.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSegarkan.BackgroundImage")));
            this.btnSegarkan.ButtonText = "Segarkan Transaksi";
            this.btnSegarkan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSegarkan.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSegarkan.ForeColor = System.Drawing.Color.SaddleBrown;
            this.btnSegarkan.IdleBorderThickness = 1;
            this.btnSegarkan.IdleCornerRadius = 20;
            this.btnSegarkan.IdleFillColor = System.Drawing.Color.MistyRose;
            this.btnSegarkan.IdleForecolor = System.Drawing.Color.SaddleBrown;
            this.btnSegarkan.IdleLineColor = System.Drawing.Color.SaddleBrown;
            this.btnSegarkan.Location = new System.Drawing.Point(1033, 880);
            this.btnSegarkan.Margin = new System.Windows.Forms.Padding(5);
            this.btnSegarkan.Name = "btnSegarkan";
            this.btnSegarkan.Size = new System.Drawing.Size(243, 63);
            this.btnSegarkan.TabIndex = 47;
            this.btnSegarkan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnTmbhData
            // 
            this.btnTmbhData.ActiveBorderThickness = 1;
            this.btnTmbhData.ActiveCornerRadius = 20;
            this.btnTmbhData.ActiveFillColor = System.Drawing.Color.Transparent;
            this.btnTmbhData.ActiveForecolor = System.Drawing.Color.RosyBrown;
            this.btnTmbhData.ActiveLineColor = System.Drawing.Color.Black;
            this.btnTmbhData.BackColor = System.Drawing.Color.MistyRose;
            this.btnTmbhData.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnTmbhData.BackgroundImage")));
            this.btnTmbhData.ButtonText = "Tambah Transaksi";
            this.btnTmbhData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTmbhData.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTmbhData.ForeColor = System.Drawing.Color.SaddleBrown;
            this.btnTmbhData.IdleBorderThickness = 1;
            this.btnTmbhData.IdleCornerRadius = 20;
            this.btnTmbhData.IdleFillColor = System.Drawing.Color.MistyRose;
            this.btnTmbhData.IdleForecolor = System.Drawing.Color.SaddleBrown;
            this.btnTmbhData.IdleLineColor = System.Drawing.Color.SaddleBrown;
            this.btnTmbhData.Location = new System.Drawing.Point(680, 880);
            this.btnTmbhData.Margin = new System.Windows.Forms.Padding(5);
            this.btnTmbhData.Name = "btnTmbhData";
            this.btnTmbhData.Size = new System.Drawing.Size(243, 63);
            this.btnTmbhData.TabIndex = 46;
            this.btnTmbhData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bunifuCustomDataGrid1
            // 
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuCustomDataGrid1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.bunifuCustomDataGrid1.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.bunifuCustomDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuCustomDataGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.SeaGreen;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.SeaGreen;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuCustomDataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.bunifuCustomDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bunifuCustomDataGrid1.DoubleBuffered = true;
            this.bunifuCustomDataGrid1.EnableHeadersVisualStyles = false;
            this.bunifuCustomDataGrid1.HeaderBgColor = System.Drawing.Color.SeaGreen;
            this.bunifuCustomDataGrid1.HeaderForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuCustomDataGrid1.Location = new System.Drawing.Point(469, 231);
            this.bunifuCustomDataGrid1.Name = "bunifuCustomDataGrid1";
            this.bunifuCustomDataGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.bunifuCustomDataGrid1.RowTemplate.Height = 28;
            this.bunifuCustomDataGrid1.Size = new System.Drawing.Size(454, 627);
            this.bunifuCustomDataGrid1.TabIndex = 45;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label2.Location = new System.Drawing.Point(489, 144);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(390, 56);
            this.label2.TabIndex = 44;
            this.label2.Text = "TABEL DATA PENJUALAN PRODUK\r\n\r\n";
            // 
            // btnDashboard
            // 
            this.btnDashboard.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnDashboard.BackColor = System.Drawing.Color.RosyBrown;
            this.btnDashboard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDashboard.BorderRadius = 0;
            this.btnDashboard.ButtonText = "Dashboard";
            this.btnDashboard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDashboard.DisabledColor = System.Drawing.Color.Black;
            this.btnDashboard.Iconcolor = System.Drawing.Color.Transparent;
            this.btnDashboard.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_home_30px_1;
            this.btnDashboard.Iconimage_right = null;
            this.btnDashboard.Iconimage_right_Selected = null;
            this.btnDashboard.Iconimage_Selected = null;
            this.btnDashboard.IconMarginLeft = 0;
            this.btnDashboard.IconMarginRight = 0;
            this.btnDashboard.IconRightVisible = true;
            this.btnDashboard.IconRightZoom = 0D;
            this.btnDashboard.IconVisible = true;
            this.btnDashboard.IconZoom = 90D;
            this.btnDashboard.IsTab = false;
            this.btnDashboard.Location = new System.Drawing.Point(0, 273);
            this.btnDashboard.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnDashboard.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnDashboard.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnDashboard.selected = false;
            this.btnDashboard.Size = new System.Drawing.Size(362, 74);
            this.btnDashboard.TabIndex = 1;
            this.btnDashboard.Text = "Dashboard";
            this.btnDashboard.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDashboard.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnDashboard.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Tan;
            this.panel3.Controls.Add(this.bunifuCustomLabel1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1553, 49);
            this.panel3.TabIndex = 43;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.SaddleBrown;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(11, 9);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(802, 28);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "Aplikasi Rakis Computer - Halaman Kasir - Master Penjualan Produk";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.Kebawah;
            this.pictureBox1.Location = new System.Drawing.Point(-74, -99);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(477, 474);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // bunifuCustomDataGrid2
            // 
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuCustomDataGrid2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.bunifuCustomDataGrid2.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.bunifuCustomDataGrid2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuCustomDataGrid2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.SeaGreen;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.SeaGreen;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuCustomDataGrid2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.bunifuCustomDataGrid2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bunifuCustomDataGrid2.DoubleBuffered = true;
            this.bunifuCustomDataGrid2.EnableHeadersVisualStyles = false;
            this.bunifuCustomDataGrid2.HeaderBgColor = System.Drawing.Color.SeaGreen;
            this.bunifuCustomDataGrid2.HeaderForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuCustomDataGrid2.Location = new System.Drawing.Point(1033, 231);
            this.bunifuCustomDataGrid2.Name = "bunifuCustomDataGrid2";
            this.bunifuCustomDataGrid2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.bunifuCustomDataGrid2.RowTemplate.Height = 28;
            this.bunifuCustomDataGrid2.Size = new System.Drawing.Size(454, 627);
            this.bunifuCustomDataGrid2.TabIndex = 48;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.RosyBrown;
            this.panel4.Controls.Add(this.btnPO);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.btnTtgAplikasi);
            this.panel4.Controls.Add(this.btnMember);
            this.panel4.Controls.Add(this.btnService);
            this.panel4.Controls.Add(this.btnPenjualanProduk);
            this.panel4.Controls.Add(this.btnLogout);
            this.panel4.Controls.Add(this.btnDashboard);
            this.panel4.Controls.Add(this.pictureBox1);
            this.panel4.ForeColor = System.Drawing.Color.RosyBrown;
            this.panel4.Location = new System.Drawing.Point(-1, 45);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(354, 946);
            this.panel4.TabIndex = 42;
            // 
            // MasterPenjualanProduk
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(1553, 990);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnSegarkan);
            this.Controls.Add(this.btnTmbhData);
            this.Controls.Add(this.bunifuCustomDataGrid1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.bunifuCustomDataGrid2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Name = "MasterPenjualanProduk";
            this.Text = "MasterPenjualanProduk";
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid2)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private Bunifu.Framework.UI.BunifuFlatButton btnPO;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label btnTtgAplikasi;
        private Bunifu.Framework.UI.BunifuFlatButton btnMember;
        private Bunifu.Framework.UI.BunifuFlatButton btnService;
        private Bunifu.Framework.UI.BunifuFlatButton btnPenjualanProduk;
        private Bunifu.Framework.UI.BunifuFlatButton btnLogout;
        private Bunifu.Framework.UI.BunifuThinButton2 btnSegarkan;
        private Bunifu.Framework.UI.BunifuThinButton2 btnTmbhData;
        private Bunifu.Framework.UI.BunifuCustomDataGrid bunifuCustomDataGrid1;
        private System.Windows.Forms.Label label2;
        private Bunifu.Framework.UI.BunifuFlatButton btnDashboard;
        private System.Windows.Forms.Panel panel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuCustomDataGrid bunifuCustomDataGrid2;
        private System.Windows.Forms.Panel panel4;
    }
}