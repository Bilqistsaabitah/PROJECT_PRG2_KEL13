﻿namespace Project_PRG2_Kel12_RakisComputer
{
    partial class MenuAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuAdmin));
            this.txtPP = new System.Windows.Forms.TextBox();
            this.BtnPP3 = new System.Windows.Forms.Button();
            this.txtPakaian = new System.Windows.Forms.TextBox();
            this.BtnPakaian3 = new System.Windows.Forms.Button();
            this.txtMU = new System.Windows.Forms.TextBox();
            this.BtnMakeUp3 = new System.Windows.Forms.Button();
            this.txtPL = new System.Windows.Forms.TextBox();
            this.BtnPL3 = new System.Windows.Forms.Button();
            this.txtPW = new System.Windows.Forms.TextBox();
            this.BtnPW3 = new System.Windows.Forms.Button();
            this.txtPR = new System.Windows.Forms.TextBox();
            this.BtnPR3 = new System.Windows.Forms.Button();
            this.txtMember = new System.Windows.Forms.TextBox();
            this.BtnMember3 = new System.Windows.Forms.Button();
            this.txtPegawai = new System.Windows.Forms.TextBox();
            this.BtnPegawai3 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.BtnTtgAplikasi = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.header = new System.Windows.Forms.Panel();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.bunifuFlatButton11 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.BtnPP2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.BtnPakaian2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.BtnMakeUp2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.BtnPegawai2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.BtnMember2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.BtnPR2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.BtnPW2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.BtnPL2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.btnDashboard = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuImageButton3 = new Bunifu.Framework.UI.BunifuImageButton();
            this.BtnClose = new Bunifu.Framework.UI.BunifuImageButton();
            this.btnPegawai = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnMember = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnProduk = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnJenisProduk = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnDistributor = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnPO = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnService = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnPaket = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnLogout = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel1.SuspendLayout();
            this.header.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnPP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnPakaian2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnMakeUp2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnPegawai2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnMember2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnPR2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnPW2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnPL2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnClose)).BeginInit();
            this.SuspendLayout();
            // 
            // txtPP
            // 
            this.txtPP.BackColor = System.Drawing.Color.IndianRed;
            this.txtPP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPP.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold);
            this.txtPP.ForeColor = System.Drawing.Color.MistyRose;
            this.txtPP.Location = new System.Drawing.Point(1358, 809);
            this.txtPP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtPP.Multiline = true;
            this.txtPP.Name = "txtPP";
            this.txtPP.Size = new System.Drawing.Size(72, 65);
            this.txtPP.TabIndex = 117;
            this.txtPP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BtnPP3
            // 
            this.BtnPP3.BackColor = System.Drawing.Color.IndianRed;
            this.BtnPP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnPP3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnPP3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.BtnPP3.ForeColor = System.Drawing.Color.Bisque;
            this.BtnPP3.Location = new System.Drawing.Point(1262, 883);
            this.BtnPP3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnPP3.Name = "BtnPP3";
            this.BtnPP3.Size = new System.Drawing.Size(255, 51);
            this.BtnPP3.TabIndex = 116;
            this.BtnPP3.Text = "Paket";
            this.BtnPP3.UseVisualStyleBackColor = false;
            // 
            // txtPakaian
            // 
            this.txtPakaian.BackColor = System.Drawing.Color.IndianRed;
            this.txtPakaian.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPakaian.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold);
            this.txtPakaian.ForeColor = System.Drawing.Color.MistyRose;
            this.txtPakaian.Location = new System.Drawing.Point(1074, 809);
            this.txtPakaian.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtPakaian.Multiline = true;
            this.txtPakaian.Name = "txtPakaian";
            this.txtPakaian.Size = new System.Drawing.Size(63, 65);
            this.txtPakaian.TabIndex = 114;
            this.txtPakaian.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BtnPakaian3
            // 
            this.BtnPakaian3.BackColor = System.Drawing.Color.IndianRed;
            this.BtnPakaian3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnPakaian3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnPakaian3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.BtnPakaian3.ForeColor = System.Drawing.Color.Bisque;
            this.BtnPakaian3.Location = new System.Drawing.Point(980, 883);
            this.BtnPakaian3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnPakaian3.Name = "BtnPakaian3";
            this.BtnPakaian3.Size = new System.Drawing.Size(255, 51);
            this.BtnPakaian3.TabIndex = 113;
            this.BtnPakaian3.Text = "Service";
            this.BtnPakaian3.UseVisualStyleBackColor = false;
            // 
            // txtMU
            // 
            this.txtMU.BackColor = System.Drawing.Color.IndianRed;
            this.txtMU.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMU.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold);
            this.txtMU.ForeColor = System.Drawing.Color.MistyRose;
            this.txtMU.Location = new System.Drawing.Point(784, 809);
            this.txtMU.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtMU.Multiline = true;
            this.txtMU.Name = "txtMU";
            this.txtMU.Size = new System.Drawing.Size(70, 65);
            this.txtMU.TabIndex = 111;
            this.txtMU.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BtnMakeUp3
            // 
            this.BtnMakeUp3.BackColor = System.Drawing.Color.IndianRed;
            this.BtnMakeUp3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnMakeUp3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMakeUp3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.BtnMakeUp3.ForeColor = System.Drawing.Color.Bisque;
            this.BtnMakeUp3.Location = new System.Drawing.Point(687, 883);
            this.BtnMakeUp3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnMakeUp3.Name = "BtnMakeUp3";
            this.BtnMakeUp3.Size = new System.Drawing.Size(255, 51);
            this.BtnMakeUp3.TabIndex = 110;
            this.BtnMakeUp3.Text = "Purchasing Order";
            this.BtnMakeUp3.UseVisualStyleBackColor = false;
            // 
            // txtPL
            // 
            this.txtPL.BackColor = System.Drawing.Color.IndianRed;
            this.txtPL.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPL.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold);
            this.txtPL.ForeColor = System.Drawing.Color.MistyRose;
            this.txtPL.Location = new System.Drawing.Point(496, 809);
            this.txtPL.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtPL.Multiline = true;
            this.txtPL.Name = "txtPL";
            this.txtPL.Size = new System.Drawing.Size(66, 65);
            this.txtPL.TabIndex = 108;
            this.txtPL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BtnPL3
            // 
            this.BtnPL3.BackColor = System.Drawing.Color.IndianRed;
            this.BtnPL3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnPL3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnPL3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.BtnPL3.ForeColor = System.Drawing.Color.Bisque;
            this.BtnPL3.Location = new System.Drawing.Point(400, 883);
            this.BtnPL3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnPL3.Name = "BtnPL3";
            this.BtnPL3.Size = new System.Drawing.Size(261, 51);
            this.BtnPL3.TabIndex = 107;
            this.BtnPL3.Text = "Distributor";
            this.BtnPL3.UseVisualStyleBackColor = false;
            // 
            // txtPW
            // 
            this.txtPW.BackColor = System.Drawing.Color.IndianRed;
            this.txtPW.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPW.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold);
            this.txtPW.ForeColor = System.Drawing.Color.MistyRose;
            this.txtPW.Location = new System.Drawing.Point(1358, 423);
            this.txtPW.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtPW.Multiline = true;
            this.txtPW.Name = "txtPW";
            this.txtPW.Size = new System.Drawing.Size(72, 63);
            this.txtPW.TabIndex = 106;
            this.txtPW.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BtnPW3
            // 
            this.BtnPW3.BackColor = System.Drawing.Color.IndianRed;
            this.BtnPW3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnPW3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnPW3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.BtnPW3.ForeColor = System.Drawing.Color.Bisque;
            this.BtnPW3.Location = new System.Drawing.Point(1262, 498);
            this.BtnPW3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnPW3.Name = "BtnPW3";
            this.BtnPW3.Size = new System.Drawing.Size(255, 51);
            this.BtnPW3.TabIndex = 105;
            this.BtnPW3.Text = "Jenis Product";
            this.BtnPW3.UseVisualStyleBackColor = false;
            // 
            // txtPR
            // 
            this.txtPR.BackColor = System.Drawing.Color.IndianRed;
            this.txtPR.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPR.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold);
            this.txtPR.ForeColor = System.Drawing.Color.MistyRose;
            this.txtPR.Location = new System.Drawing.Point(1082, 423);
            this.txtPR.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtPR.Multiline = true;
            this.txtPR.Name = "txtPR";
            this.txtPR.Size = new System.Drawing.Size(63, 63);
            this.txtPR.TabIndex = 104;
            this.txtPR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BtnPR3
            // 
            this.BtnPR3.BackColor = System.Drawing.Color.IndianRed;
            this.BtnPR3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnPR3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnPR3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.BtnPR3.ForeColor = System.Drawing.Color.Bisque;
            this.BtnPR3.Location = new System.Drawing.Point(980, 498);
            this.BtnPR3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnPR3.Name = "BtnPR3";
            this.BtnPR3.Size = new System.Drawing.Size(255, 51);
            this.BtnPR3.TabIndex = 103;
            this.BtnPR3.Text = "Product";
            this.BtnPR3.UseVisualStyleBackColor = false;
            // 
            // txtMember
            // 
            this.txtMember.BackColor = System.Drawing.Color.IndianRed;
            this.txtMember.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMember.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold);
            this.txtMember.ForeColor = System.Drawing.Color.MistyRose;
            this.txtMember.Location = new System.Drawing.Point(784, 423);
            this.txtMember.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtMember.Multiline = true;
            this.txtMember.Name = "txtMember";
            this.txtMember.Size = new System.Drawing.Size(70, 63);
            this.txtMember.TabIndex = 102;
            this.txtMember.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BtnMember3
            // 
            this.BtnMember3.BackColor = System.Drawing.Color.IndianRed;
            this.BtnMember3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnMember3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMember3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.BtnMember3.ForeColor = System.Drawing.Color.Bisque;
            this.BtnMember3.Location = new System.Drawing.Point(687, 498);
            this.BtnMember3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnMember3.Name = "BtnMember3";
            this.BtnMember3.Size = new System.Drawing.Size(255, 51);
            this.BtnMember3.TabIndex = 101;
            this.BtnMember3.Text = "Member";
            this.BtnMember3.UseVisualStyleBackColor = false;
            // 
            // txtPegawai
            // 
            this.txtPegawai.BackColor = System.Drawing.Color.IndianRed;
            this.txtPegawai.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPegawai.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPegawai.ForeColor = System.Drawing.Color.MistyRose;
            this.txtPegawai.Location = new System.Drawing.Point(496, 423);
            this.txtPegawai.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtPegawai.Multiline = true;
            this.txtPegawai.Name = "txtPegawai";
            this.txtPegawai.Size = new System.Drawing.Size(66, 63);
            this.txtPegawai.TabIndex = 100;
            this.txtPegawai.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BtnPegawai3
            // 
            this.BtnPegawai3.BackColor = System.Drawing.Color.IndianRed;
            this.BtnPegawai3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnPegawai3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnPegawai3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.BtnPegawai3.ForeColor = System.Drawing.Color.Bisque;
            this.BtnPegawai3.Location = new System.Drawing.Point(400, 498);
            this.BtnPegawai3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnPegawai3.Name = "BtnPegawai3";
            this.BtnPegawai3.Size = new System.Drawing.Size(261, 51);
            this.BtnPegawai3.TabIndex = 99;
            this.BtnPegawai3.Text = "Employee";
            this.BtnPegawai3.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.RosyBrown;
            this.panel1.Controls.Add(this.btnLogout);
            this.panel1.Controls.Add(this.btnPaket);
            this.panel1.Controls.Add(this.btnService);
            this.panel1.Controls.Add(this.btnPO);
            this.panel1.Controls.Add(this.btnDistributor);
            this.panel1.Controls.Add(this.btnJenisProduk);
            this.panel1.Controls.Add(this.btnProduk);
            this.panel1.Controls.Add(this.btnMember);
            this.panel1.Controls.Add(this.btnPegawai);
            this.panel1.Controls.Add(this.btnDashboard);
            this.panel1.Controls.Add(this.BtnTtgAplikasi);
            this.panel1.Controls.Add(this.bunifuCustomLabel2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 54);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(348, 996);
            this.panel1.TabIndex = 92;
            // 
            // BtnTtgAplikasi
            // 
            this.BtnTtgAplikasi.AutoSize = true;
            this.BtnTtgAplikasi.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTtgAplikasi.ForeColor = System.Drawing.Color.SaddleBrown;
            this.BtnTtgAplikasi.Location = new System.Drawing.Point(104, 928);
            this.BtnTtgAplikasi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.BtnTtgAplikasi.Name = "BtnTtgAplikasi";
            this.BtnTtgAplikasi.Size = new System.Drawing.Size(146, 21);
            this.BtnTtgAplikasi.TabIndex = 19;
            this.BtnTtgAplikasi.Text = "Tentang Aplikasi";
            this.BtnTtgAplikasi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.SaddleBrown;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(-4, 949);
            this.bunifuCustomLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(353, 21);
            this.bunifuCustomLabel2.TabIndex = 7;
            this.bunifuCustomLabel2.Text = "Bilqis Tsaabitah && Ramadhan Dewantara";
            this.bunifuCustomLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Century Gothic", 12.75F, System.Drawing.FontStyle.Bold);
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.Bisque;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(330, 11);
            this.bunifuCustomLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(249, 30);
            this.bunifuCustomLabel1.TabIndex = 4;
            this.bunifuCustomLabel1.Text = "-   Halaman Admin";
            // 
            // header
            // 
            this.header.BackColor = System.Drawing.Color.Tan;
            this.header.Controls.Add(this.bunifuImageButton3);
            this.header.Controls.Add(this.BtnClose);
            this.header.Controls.Add(this.bunifuCustomLabel3);
            this.header.Controls.Add(this.bunifuCustomLabel1);
            this.header.Dock = System.Windows.Forms.DockStyle.Top;
            this.header.Location = new System.Drawing.Point(0, 0);
            this.header.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.header.Name = "header";
            this.header.Size = new System.Drawing.Size(1562, 54);
            this.header.TabIndex = 93;
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Century Gothic", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.Bisque;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(56, 11);
            this.bunifuCustomLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(267, 30);
            this.bunifuCustomLabel3.TabIndex = 6;
            this.bunifuCustomLabel3.Text = "Aplikasi Salon Hawa";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.IndianRed;
            this.pictureBox2.Location = new System.Drawing.Point(378, 152);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1164, 2);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 118;
            this.pictureBox2.TabStop = false;
            // 
            // bunifuFlatButton11
            // 
            this.bunifuFlatButton11.Activecolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton11.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton11.BorderRadius = 0;
            this.bunifuFlatButton11.ButtonText = "     Dashboard";
            this.bunifuFlatButton11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton11.DisabledColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton11.Enabled = false;
            this.bunifuFlatButton11.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton11.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton11.Iconimage")));
            this.bunifuFlatButton11.Iconimage_right = null;
            this.bunifuFlatButton11.Iconimage_right_Selected = null;
            this.bunifuFlatButton11.Iconimage_Selected = null;
            this.bunifuFlatButton11.IconMarginLeft = 0;
            this.bunifuFlatButton11.IconMarginRight = 0;
            this.bunifuFlatButton11.IconRightVisible = true;
            this.bunifuFlatButton11.IconRightZoom = 0D;
            this.bunifuFlatButton11.IconVisible = true;
            this.bunifuFlatButton11.IconZoom = 50D;
            this.bunifuFlatButton11.IsTab = true;
            this.bunifuFlatButton11.Location = new System.Drawing.Point(378, 78);
            this.bunifuFlatButton11.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.bunifuFlatButton11.Name = "bunifuFlatButton11";
            this.bunifuFlatButton11.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton11.OnHovercolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton11.OnHoverTextColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton11.selected = true;
            this.bunifuFlatButton11.Size = new System.Drawing.Size(232, 46);
            this.bunifuFlatButton11.TabIndex = 119;
            this.bunifuFlatButton11.Text = "     Dashboard";
            this.bunifuFlatButton11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton11.Textcolor = System.Drawing.Color.IndianRed;
            this.bunifuFlatButton11.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // BtnPP2
            // 
            this.BtnPP2.BackColor = System.Drawing.Color.IndianRed;
            this.BtnPP2.Image = ((System.Drawing.Image)(resources.GetObject("BtnPP2.Image")));
            this.BtnPP2.ImageActive = null;
            this.BtnPP2.Location = new System.Drawing.Point(1274, 606);
            this.BtnPP2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnPP2.Name = "BtnPP2";
            this.BtnPP2.Size = new System.Drawing.Size(231, 275);
            this.BtnPP2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.BtnPP2.TabIndex = 115;
            this.BtnPP2.TabStop = false;
            this.BtnPP2.Zoom = 10;
            // 
            // BtnPakaian2
            // 
            this.BtnPakaian2.BackColor = System.Drawing.Color.IndianRed;
            this.BtnPakaian2.Image = ((System.Drawing.Image)(resources.GetObject("BtnPakaian2.Image")));
            this.BtnPakaian2.ImageActive = null;
            this.BtnPakaian2.Location = new System.Drawing.Point(988, 606);
            this.BtnPakaian2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnPakaian2.Name = "BtnPakaian2";
            this.BtnPakaian2.Size = new System.Drawing.Size(231, 275);
            this.BtnPakaian2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.BtnPakaian2.TabIndex = 112;
            this.BtnPakaian2.TabStop = false;
            this.BtnPakaian2.Zoom = 10;
            // 
            // BtnMakeUp2
            // 
            this.BtnMakeUp2.BackColor = System.Drawing.Color.IndianRed;
            this.BtnMakeUp2.Image = ((System.Drawing.Image)(resources.GetObject("BtnMakeUp2.Image")));
            this.BtnMakeUp2.ImageActive = null;
            this.BtnMakeUp2.Location = new System.Drawing.Point(698, 606);
            this.BtnMakeUp2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnMakeUp2.Name = "BtnMakeUp2";
            this.BtnMakeUp2.Size = new System.Drawing.Size(231, 275);
            this.BtnMakeUp2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.BtnMakeUp2.TabIndex = 109;
            this.BtnMakeUp2.TabStop = false;
            this.BtnMakeUp2.Zoom = 10;
            // 
            // BtnPegawai2
            // 
            this.BtnPegawai2.BackColor = System.Drawing.Color.IndianRed;
            this.BtnPegawai2.Image = ((System.Drawing.Image)(resources.GetObject("BtnPegawai2.Image")));
            this.BtnPegawai2.ImageActive = null;
            this.BtnPegawai2.Location = new System.Drawing.Point(416, 222);
            this.BtnPegawai2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnPegawai2.Name = "BtnPegawai2";
            this.BtnPegawai2.Size = new System.Drawing.Size(231, 275);
            this.BtnPegawai2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.BtnPegawai2.TabIndex = 98;
            this.BtnPegawai2.TabStop = false;
            this.BtnPegawai2.Zoom = 10;
            // 
            // BtnMember2
            // 
            this.BtnMember2.BackColor = System.Drawing.Color.IndianRed;
            this.BtnMember2.Image = ((System.Drawing.Image)(resources.GetObject("BtnMember2.Image")));
            this.BtnMember2.ImageActive = null;
            this.BtnMember2.Location = new System.Drawing.Point(698, 222);
            this.BtnMember2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnMember2.Name = "BtnMember2";
            this.BtnMember2.Size = new System.Drawing.Size(231, 275);
            this.BtnMember2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.BtnMember2.TabIndex = 97;
            this.BtnMember2.TabStop = false;
            this.BtnMember2.Zoom = 10;
            // 
            // BtnPR2
            // 
            this.BtnPR2.BackColor = System.Drawing.Color.IndianRed;
            this.BtnPR2.Image = ((System.Drawing.Image)(resources.GetObject("BtnPR2.Image")));
            this.BtnPR2.ImageActive = null;
            this.BtnPR2.Location = new System.Drawing.Point(988, 222);
            this.BtnPR2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnPR2.Name = "BtnPR2";
            this.BtnPR2.Size = new System.Drawing.Size(231, 275);
            this.BtnPR2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.BtnPR2.TabIndex = 96;
            this.BtnPR2.TabStop = false;
            this.BtnPR2.Zoom = 10;
            // 
            // BtnPW2
            // 
            this.BtnPW2.BackColor = System.Drawing.Color.IndianRed;
            this.BtnPW2.Image = ((System.Drawing.Image)(resources.GetObject("BtnPW2.Image")));
            this.BtnPW2.ImageActive = null;
            this.BtnPW2.Location = new System.Drawing.Point(1274, 222);
            this.BtnPW2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnPW2.Name = "BtnPW2";
            this.BtnPW2.Size = new System.Drawing.Size(231, 275);
            this.BtnPW2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.BtnPW2.TabIndex = 95;
            this.BtnPW2.TabStop = false;
            this.BtnPW2.Zoom = 10;
            // 
            // BtnPL2
            // 
            this.BtnPL2.BackColor = System.Drawing.Color.IndianRed;
            this.BtnPL2.Image = ((System.Drawing.Image)(resources.GetObject("BtnPL2.Image")));
            this.BtnPL2.ImageActive = null;
            this.BtnPL2.Location = new System.Drawing.Point(416, 606);
            this.BtnPL2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnPL2.Name = "BtnPL2";
            this.BtnPL2.Size = new System.Drawing.Size(231, 275);
            this.BtnPL2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.BtnPL2.TabIndex = 94;
            this.BtnPL2.TabStop = false;
            this.BtnPL2.Zoom = 10;
            // 
            // btnDashboard
            // 
            this.btnDashboard.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnDashboard.BackColor = System.Drawing.Color.RosyBrown;
            this.btnDashboard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDashboard.BorderRadius = 0;
            this.btnDashboard.ButtonText = "Dashboard";
            this.btnDashboard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDashboard.DisabledColor = System.Drawing.Color.Black;
            this.btnDashboard.Iconcolor = System.Drawing.Color.Transparent;
            this.btnDashboard.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_home_30px_1;
            this.btnDashboard.Iconimage_right = null;
            this.btnDashboard.Iconimage_right_Selected = null;
            this.btnDashboard.Iconimage_Selected = null;
            this.btnDashboard.IconMarginLeft = 0;
            this.btnDashboard.IconMarginRight = 0;
            this.btnDashboard.IconRightVisible = true;
            this.btnDashboard.IconRightZoom = 0D;
            this.btnDashboard.IconVisible = true;
            this.btnDashboard.IconZoom = 90D;
            this.btnDashboard.IsTab = false;
            this.btnDashboard.Location = new System.Drawing.Point(0, 263);
            this.btnDashboard.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnDashboard.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnDashboard.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnDashboard.selected = false;
            this.btnDashboard.Size = new System.Drawing.Size(362, 74);
            this.btnDashboard.TabIndex = 20;
            this.btnDashboard.Text = "Dashboard";
            this.btnDashboard.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDashboard.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnDashboard.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.Kebawah2;
            this.pictureBox1.Location = new System.Drawing.Point(-68, -100);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(457, 489);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // bunifuImageButton3
            // 
            this.bunifuImageButton3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton3.Image")));
            this.bunifuImageButton3.ImageActive = null;
            this.bunifuImageButton3.Location = new System.Drawing.Point(14, 6);
            this.bunifuImageButton3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bunifuImageButton3.Name = "bunifuImageButton3";
            this.bunifuImageButton3.Size = new System.Drawing.Size(38, 38);
            this.bunifuImageButton3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton3.TabIndex = 6;
            this.bunifuImageButton3.TabStop = false;
            this.bunifuImageButton3.Zoom = 10;
            // 
            // BtnClose
            // 
            this.BtnClose.BackColor = System.Drawing.Color.Transparent;
            this.BtnClose.Image = ((System.Drawing.Image)(resources.GetObject("BtnClose.Image")));
            this.BtnClose.ImageActive = null;
            this.BtnClose.Location = new System.Drawing.Point(1497, -2);
            this.BtnClose.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(45, 46);
            this.BtnClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BtnClose.TabIndex = 6;
            this.BtnClose.TabStop = false;
            this.BtnClose.Zoom = 10;
            // 
            // btnPegawai
            // 
            this.btnPegawai.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnPegawai.BackColor = System.Drawing.Color.RosyBrown;
            this.btnPegawai.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPegawai.BorderRadius = 0;
            this.btnPegawai.ButtonText = "Employee";
            this.btnPegawai.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPegawai.DisabledColor = System.Drawing.Color.Black;
            this.btnPegawai.Iconcolor = System.Drawing.Color.Transparent;
            this.btnPegawai.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_exit_30px;
            this.btnPegawai.Iconimage_right = null;
            this.btnPegawai.Iconimage_right_Selected = null;
            this.btnPegawai.Iconimage_Selected = null;
            this.btnPegawai.IconMarginLeft = 0;
            this.btnPegawai.IconMarginRight = 0;
            this.btnPegawai.IconRightVisible = true;
            this.btnPegawai.IconRightZoom = 0D;
            this.btnPegawai.IconVisible = true;
            this.btnPegawai.IconZoom = 90D;
            this.btnPegawai.IsTab = false;
            this.btnPegawai.Location = new System.Drawing.Point(0, 325);
            this.btnPegawai.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPegawai.Name = "btnPegawai";
            this.btnPegawai.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnPegawai.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnPegawai.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnPegawai.selected = false;
            this.btnPegawai.Size = new System.Drawing.Size(362, 74);
            this.btnPegawai.TabIndex = 21;
            this.btnPegawai.Text = "Employee";
            this.btnPegawai.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnPegawai.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnPegawai.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnMember
            // 
            this.btnMember.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnMember.BackColor = System.Drawing.Color.RosyBrown;
            this.btnMember.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMember.BorderRadius = 0;
            this.btnMember.ButtonText = "Member";
            this.btnMember.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMember.DisabledColor = System.Drawing.Color.Black;
            this.btnMember.Iconcolor = System.Drawing.Color.Transparent;
            this.btnMember.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_name_tag_64;
            this.btnMember.Iconimage_right = null;
            this.btnMember.Iconimage_right_Selected = null;
            this.btnMember.Iconimage_Selected = null;
            this.btnMember.IconMarginLeft = 0;
            this.btnMember.IconMarginRight = 0;
            this.btnMember.IconRightVisible = true;
            this.btnMember.IconRightZoom = 0D;
            this.btnMember.IconVisible = true;
            this.btnMember.IconZoom = 90D;
            this.btnMember.IsTab = false;
            this.btnMember.Location = new System.Drawing.Point(0, 387);
            this.btnMember.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnMember.Name = "btnMember";
            this.btnMember.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnMember.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnMember.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnMember.selected = false;
            this.btnMember.Size = new System.Drawing.Size(362, 76);
            this.btnMember.TabIndex = 22;
            this.btnMember.Text = "Member";
            this.btnMember.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnMember.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnMember.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnProduk
            // 
            this.btnProduk.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnProduk.BackColor = System.Drawing.Color.RosyBrown;
            this.btnProduk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnProduk.BorderRadius = 0;
            this.btnProduk.ButtonText = "Product";
            this.btnProduk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProduk.DisabledColor = System.Drawing.Color.Black;
            this.btnProduk.Iconcolor = System.Drawing.Color.Transparent;
            this.btnProduk.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_shopping_basket_30px;
            this.btnProduk.Iconimage_right = null;
            this.btnProduk.Iconimage_right_Selected = null;
            this.btnProduk.Iconimage_Selected = null;
            this.btnProduk.IconMarginLeft = 0;
            this.btnProduk.IconMarginRight = 0;
            this.btnProduk.IconRightVisible = true;
            this.btnProduk.IconRightZoom = 0D;
            this.btnProduk.IconVisible = true;
            this.btnProduk.IconZoom = 90D;
            this.btnProduk.IsTab = false;
            this.btnProduk.Location = new System.Drawing.Point(0, 453);
            this.btnProduk.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnProduk.Name = "btnProduk";
            this.btnProduk.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnProduk.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnProduk.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnProduk.selected = false;
            this.btnProduk.Size = new System.Drawing.Size(362, 74);
            this.btnProduk.TabIndex = 23;
            this.btnProduk.Text = "Product";
            this.btnProduk.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnProduk.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnProduk.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnJenisProduk
            // 
            this.btnJenisProduk.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnJenisProduk.BackColor = System.Drawing.Color.RosyBrown;
            this.btnJenisProduk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnJenisProduk.BorderRadius = 0;
            this.btnJenisProduk.ButtonText = "Jenis Product";
            this.btnJenisProduk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnJenisProduk.DisabledColor = System.Drawing.Color.Black;
            this.btnJenisProduk.Iconcolor = System.Drawing.Color.Transparent;
            this.btnJenisProduk.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_tasks_30px;
            this.btnJenisProduk.Iconimage_right = null;
            this.btnJenisProduk.Iconimage_right_Selected = null;
            this.btnJenisProduk.Iconimage_Selected = null;
            this.btnJenisProduk.IconMarginLeft = 0;
            this.btnJenisProduk.IconMarginRight = 0;
            this.btnJenisProduk.IconRightVisible = true;
            this.btnJenisProduk.IconRightZoom = 0D;
            this.btnJenisProduk.IconVisible = true;
            this.btnJenisProduk.IconZoom = 90D;
            this.btnJenisProduk.IsTab = false;
            this.btnJenisProduk.Location = new System.Drawing.Point(0, 514);
            this.btnJenisProduk.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnJenisProduk.Name = "btnJenisProduk";
            this.btnJenisProduk.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnJenisProduk.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnJenisProduk.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnJenisProduk.selected = false;
            this.btnJenisProduk.Size = new System.Drawing.Size(362, 74);
            this.btnJenisProduk.TabIndex = 24;
            this.btnJenisProduk.Text = "Jenis Product";
            this.btnJenisProduk.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnJenisProduk.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnJenisProduk.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnDistributor
            // 
            this.btnDistributor.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnDistributor.BackColor = System.Drawing.Color.RosyBrown;
            this.btnDistributor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDistributor.BorderRadius = 0;
            this.btnDistributor.ButtonText = "Distributor";
            this.btnDistributor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDistributor.DisabledColor = System.Drawing.Color.Black;
            this.btnDistributor.Iconcolor = System.Drawing.Color.Transparent;
            this.btnDistributor.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_shopping_bag_30px;
            this.btnDistributor.Iconimage_right = null;
            this.btnDistributor.Iconimage_right_Selected = null;
            this.btnDistributor.Iconimage_Selected = null;
            this.btnDistributor.IconMarginLeft = 0;
            this.btnDistributor.IconMarginRight = 0;
            this.btnDistributor.IconRightVisible = true;
            this.btnDistributor.IconRightZoom = 0D;
            this.btnDistributor.IconVisible = true;
            this.btnDistributor.IconZoom = 90D;
            this.btnDistributor.IsTab = false;
            this.btnDistributor.Location = new System.Drawing.Point(0, 577);
            this.btnDistributor.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDistributor.Name = "btnDistributor";
            this.btnDistributor.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnDistributor.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnDistributor.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnDistributor.selected = false;
            this.btnDistributor.Size = new System.Drawing.Size(362, 74);
            this.btnDistributor.TabIndex = 25;
            this.btnDistributor.Text = "Distributor";
            this.btnDistributor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDistributor.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnDistributor.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnPO
            // 
            this.btnPO.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnPO.BackColor = System.Drawing.Color.RosyBrown;
            this.btnPO.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPO.BorderRadius = 0;
            this.btnPO.ButtonText = "Purchasing Order";
            this.btnPO.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPO.DisabledColor = System.Drawing.Color.Black;
            this.btnPO.Iconcolor = System.Drawing.Color.Transparent;
            this.btnPO.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_checkout_30px_2;
            this.btnPO.Iconimage_right = null;
            this.btnPO.Iconimage_right_Selected = null;
            this.btnPO.Iconimage_Selected = null;
            this.btnPO.IconMarginLeft = 0;
            this.btnPO.IconMarginRight = 0;
            this.btnPO.IconRightVisible = true;
            this.btnPO.IconRightZoom = 0D;
            this.btnPO.IconVisible = true;
            this.btnPO.IconZoom = 90D;
            this.btnPO.IsTab = false;
            this.btnPO.Location = new System.Drawing.Point(0, 636);
            this.btnPO.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.btnPO.Name = "btnPO";
            this.btnPO.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnPO.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnPO.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnPO.selected = false;
            this.btnPO.Size = new System.Drawing.Size(362, 74);
            this.btnPO.TabIndex = 26;
            this.btnPO.Text = "Purchasing Order";
            this.btnPO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnPO.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnPO.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnService
            // 
            this.btnService.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnService.BackColor = System.Drawing.Color.RosyBrown;
            this.btnService.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnService.BorderRadius = 0;
            this.btnService.ButtonText = "Service";
            this.btnService.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnService.DisabledColor = System.Drawing.Color.Black;
            this.btnService.Iconcolor = System.Drawing.Color.Transparent;
            this.btnService.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_maintenance_30px;
            this.btnService.Iconimage_right = null;
            this.btnService.Iconimage_right_Selected = null;
            this.btnService.Iconimage_Selected = null;
            this.btnService.IconMarginLeft = 0;
            this.btnService.IconMarginRight = 0;
            this.btnService.IconRightVisible = true;
            this.btnService.IconRightZoom = 0D;
            this.btnService.IconVisible = true;
            this.btnService.IconZoom = 90D;
            this.btnService.IsTab = false;
            this.btnService.Location = new System.Drawing.Point(0, 702);
            this.btnService.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnService.Name = "btnService";
            this.btnService.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnService.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnService.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnService.selected = false;
            this.btnService.Size = new System.Drawing.Size(362, 74);
            this.btnService.TabIndex = 27;
            this.btnService.Text = "Service";
            this.btnService.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnService.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnService.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnPaket
            // 
            this.btnPaket.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnPaket.BackColor = System.Drawing.Color.RosyBrown;
            this.btnPaket.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPaket.BorderRadius = 0;
            this.btnPaket.ButtonText = "Paket";
            this.btnPaket.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPaket.DisabledColor = System.Drawing.Color.Black;
            this.btnPaket.Iconcolor = System.Drawing.Color.Transparent;
            this.btnPaket.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_new_job_30px;
            this.btnPaket.Iconimage_right = null;
            this.btnPaket.Iconimage_right_Selected = null;
            this.btnPaket.Iconimage_Selected = null;
            this.btnPaket.IconMarginLeft = 0;
            this.btnPaket.IconMarginRight = 0;
            this.btnPaket.IconRightVisible = true;
            this.btnPaket.IconRightZoom = 0D;
            this.btnPaket.IconVisible = true;
            this.btnPaket.IconZoom = 90D;
            this.btnPaket.IsTab = false;
            this.btnPaket.Location = new System.Drawing.Point(0, 767);
            this.btnPaket.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPaket.Name = "btnPaket";
            this.btnPaket.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnPaket.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnPaket.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnPaket.selected = false;
            this.btnPaket.Size = new System.Drawing.Size(362, 74);
            this.btnPaket.TabIndex = 28;
            this.btnPaket.Text = "Paket";
            this.btnPaket.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnPaket.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnPaket.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnLogout
            // 
            this.btnLogout.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnLogout.BackColor = System.Drawing.Color.RosyBrown;
            this.btnLogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLogout.BorderRadius = 0;
            this.btnLogout.ButtonText = "Logout";
            this.btnLogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogout.DisabledColor = System.Drawing.Color.Black;
            this.btnLogout.Iconcolor = System.Drawing.Color.Transparent;
            this.btnLogout.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_exit_30px;
            this.btnLogout.Iconimage_right = null;
            this.btnLogout.Iconimage_right_Selected = null;
            this.btnLogout.Iconimage_Selected = null;
            this.btnLogout.IconMarginLeft = 0;
            this.btnLogout.IconMarginRight = 0;
            this.btnLogout.IconRightVisible = true;
            this.btnLogout.IconRightZoom = 0D;
            this.btnLogout.IconVisible = true;
            this.btnLogout.IconZoom = 90D;
            this.btnLogout.IsTab = false;
            this.btnLogout.Location = new System.Drawing.Point(0, 840);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnLogout.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnLogout.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnLogout.selected = false;
            this.btnLogout.Size = new System.Drawing.Size(362, 74);
            this.btnLogout.TabIndex = 29;
            this.btnLogout.Text = "Logout";
            this.btnLogout.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnLogout.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnLogout.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // MenuAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(1562, 1050);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.bunifuFlatButton11);
            this.Controls.Add(this.txtPP);
            this.Controls.Add(this.BtnPP3);
            this.Controls.Add(this.BtnPP2);
            this.Controls.Add(this.txtPakaian);
            this.Controls.Add(this.BtnPakaian3);
            this.Controls.Add(this.BtnPakaian2);
            this.Controls.Add(this.txtMU);
            this.Controls.Add(this.BtnMakeUp3);
            this.Controls.Add(this.BtnMakeUp2);
            this.Controls.Add(this.txtPL);
            this.Controls.Add(this.BtnPL3);
            this.Controls.Add(this.txtPW);
            this.Controls.Add(this.BtnPW3);
            this.Controls.Add(this.txtPR);
            this.Controls.Add(this.BtnPR3);
            this.Controls.Add(this.txtMember);
            this.Controls.Add(this.BtnMember3);
            this.Controls.Add(this.txtPegawai);
            this.Controls.Add(this.BtnPegawai3);
            this.Controls.Add(this.BtnPegawai2);
            this.Controls.Add(this.BtnMember2);
            this.Controls.Add(this.BtnPR2);
            this.Controls.Add(this.BtnPW2);
            this.Controls.Add(this.BtnPL2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.header);
            this.Name = "MenuAdmin";
            this.Text = "MenuAdmin";
            this.Load += new System.EventHandler(this.MenuAdmin_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.header.ResumeLayout(false);
            this.header.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnPP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnPakaian2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnMakeUp2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnPegawai2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnMember2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnPR2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnPW2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnPL2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnClose)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton11;
        private System.Windows.Forms.TextBox txtPP;
        private System.Windows.Forms.Button BtnPP3;
        private Bunifu.Framework.UI.BunifuImageButton BtnPP2;
        private System.Windows.Forms.TextBox txtPakaian;
        private System.Windows.Forms.Button BtnPakaian3;
        private Bunifu.Framework.UI.BunifuImageButton BtnPakaian2;
        private System.Windows.Forms.TextBox txtMU;
        private System.Windows.Forms.Button BtnMakeUp3;
        private Bunifu.Framework.UI.BunifuImageButton BtnMakeUp2;
        private System.Windows.Forms.TextBox txtPL;
        private System.Windows.Forms.Button BtnPL3;
        private System.Windows.Forms.TextBox txtPW;
        private System.Windows.Forms.Button BtnPW3;
        private System.Windows.Forms.TextBox txtPR;
        private System.Windows.Forms.Button BtnPR3;
        private System.Windows.Forms.TextBox txtMember;
        private System.Windows.Forms.Button BtnMember3;
        private System.Windows.Forms.TextBox txtPegawai;
        private System.Windows.Forms.Button BtnPegawai3;
        private Bunifu.Framework.UI.BunifuImageButton BtnPegawai2;
        private Bunifu.Framework.UI.BunifuImageButton BtnMember2;
        private Bunifu.Framework.UI.BunifuImageButton BtnPR2;
        private Bunifu.Framework.UI.BunifuImageButton BtnPW2;
        private Bunifu.Framework.UI.BunifuImageButton BtnPL2;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuCustomLabel BtnTtgAplikasi;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private System.Windows.Forms.Panel header;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton3;
        private Bunifu.Framework.UI.BunifuImageButton BtnClose;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuFlatButton btnDashboard;
        private Bunifu.Framework.UI.BunifuFlatButton btnPegawai;
        private Bunifu.Framework.UI.BunifuFlatButton btnMember;
        private Bunifu.Framework.UI.BunifuFlatButton btnProduk;
        private Bunifu.Framework.UI.BunifuFlatButton btnJenisProduk;
        private Bunifu.Framework.UI.BunifuFlatButton btnDistributor;
        private Bunifu.Framework.UI.BunifuFlatButton btnPO;
        private Bunifu.Framework.UI.BunifuFlatButton btnService;
        private Bunifu.Framework.UI.BunifuFlatButton btnPaket;
        private Bunifu.Framework.UI.BunifuFlatButton btnLogout;
    }
}