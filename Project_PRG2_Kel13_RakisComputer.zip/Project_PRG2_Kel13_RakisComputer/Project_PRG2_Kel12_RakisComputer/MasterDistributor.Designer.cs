﻿namespace Project_PRG2_Kel12_RakisComputer
{
    partial class MasterDistributor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MasterDistributor));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnPaket = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnService = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnDistributor = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnPO = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnJenisProduk = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnLogout = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnProduk = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnMember = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnPegawai = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label1 = new System.Windows.Forms.Label();
            this.btnTtgAplikasi = new System.Windows.Forms.Label();
            this.btnDashboard = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.BtnClose = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomDataGrid1 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.idDistributorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.namaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.alamatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nohpDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.distributorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.db_Rakis_computerrDataSet = new Project_PRG2_Kel12_RakisComputer.db_Rakis_computerrDataSet();
            this.label2 = new System.Windows.Forms.Label();
            this.btnUbahData = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnTmbhData = new Bunifu.Framework.UI.BunifuThinButton2();
            this.distributorTableAdapter = new Project_PRG2_Kel12_RakisComputer.db_Rakis_computerrDataSetTableAdapters.DistributorTableAdapter();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BtnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.distributorBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.db_Rakis_computerrDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.RosyBrown;
            this.panel1.Controls.Add(this.btnPaket);
            this.panel1.Controls.Add(this.btnService);
            this.panel1.Controls.Add(this.btnDistributor);
            this.panel1.Controls.Add(this.btnPO);
            this.panel1.Controls.Add(this.btnJenisProduk);
            this.panel1.Controls.Add(this.btnLogout);
            this.panel1.Controls.Add(this.btnProduk);
            this.panel1.Controls.Add(this.btnMember);
            this.panel1.Controls.Add(this.btnPegawai);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnTtgAplikasi);
            this.panel1.Controls.Add(this.btnDashboard);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.ForeColor = System.Drawing.Color.RosyBrown;
            this.panel1.Location = new System.Drawing.Point(-1, 45);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(363, 994);
            this.panel1.TabIndex = 46;
            // 
            // btnPaket
            // 
            this.btnPaket.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnPaket.BackColor = System.Drawing.Color.RosyBrown;
            this.btnPaket.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPaket.BorderRadius = 0;
            this.btnPaket.ButtonText = "Paket";
            this.btnPaket.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPaket.DisabledColor = System.Drawing.Color.Black;
            this.btnPaket.Iconcolor = System.Drawing.Color.Transparent;
            this.btnPaket.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_new_job_30px;
            this.btnPaket.Iconimage_right = null;
            this.btnPaket.Iconimage_right_Selected = null;
            this.btnPaket.Iconimage_Selected = null;
            this.btnPaket.IconMarginLeft = 0;
            this.btnPaket.IconMarginRight = 0;
            this.btnPaket.IconRightVisible = true;
            this.btnPaket.IconRightZoom = 0D;
            this.btnPaket.IconVisible = true;
            this.btnPaket.IconZoom = 90D;
            this.btnPaket.IsTab = false;
            this.btnPaket.Location = new System.Drawing.Point(4, 743);
            this.btnPaket.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPaket.Name = "btnPaket";
            this.btnPaket.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnPaket.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnPaket.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnPaket.selected = false;
            this.btnPaket.Size = new System.Drawing.Size(362, 74);
            this.btnPaket.TabIndex = 51;
            this.btnPaket.Text = "Paket";
            this.btnPaket.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnPaket.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnPaket.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPaket.Click += new System.EventHandler(this.btnPaket_Click);
            // 
            // btnService
            // 
            this.btnService.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnService.BackColor = System.Drawing.Color.RosyBrown;
            this.btnService.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnService.BorderRadius = 0;
            this.btnService.ButtonText = "Service";
            this.btnService.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnService.DisabledColor = System.Drawing.Color.Black;
            this.btnService.Iconcolor = System.Drawing.Color.Transparent;
            this.btnService.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_maintenance_30px;
            this.btnService.Iconimage_right = null;
            this.btnService.Iconimage_right_Selected = null;
            this.btnService.Iconimage_Selected = null;
            this.btnService.IconMarginLeft = 0;
            this.btnService.IconMarginRight = 0;
            this.btnService.IconRightVisible = true;
            this.btnService.IconRightZoom = 0D;
            this.btnService.IconVisible = true;
            this.btnService.IconZoom = 90D;
            this.btnService.IsTab = false;
            this.btnService.Location = new System.Drawing.Point(1, 681);
            this.btnService.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnService.Name = "btnService";
            this.btnService.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnService.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnService.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnService.selected = false;
            this.btnService.Size = new System.Drawing.Size(362, 74);
            this.btnService.TabIndex = 51;
            this.btnService.Text = "Service";
            this.btnService.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnService.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnService.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnService.Click += new System.EventHandler(this.btnService_Click);
            // 
            // btnDistributor
            // 
            this.btnDistributor.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnDistributor.BackColor = System.Drawing.Color.RosyBrown;
            this.btnDistributor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDistributor.BorderRadius = 0;
            this.btnDistributor.ButtonText = "Distributor";
            this.btnDistributor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDistributor.DisabledColor = System.Drawing.Color.Black;
            this.btnDistributor.Iconcolor = System.Drawing.Color.Transparent;
            this.btnDistributor.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_shopping_bag_30px;
            this.btnDistributor.Iconimage_right = null;
            this.btnDistributor.Iconimage_right_Selected = null;
            this.btnDistributor.Iconimage_Selected = null;
            this.btnDistributor.IconMarginLeft = 0;
            this.btnDistributor.IconMarginRight = 0;
            this.btnDistributor.IconRightVisible = true;
            this.btnDistributor.IconRightZoom = 0D;
            this.btnDistributor.IconVisible = true;
            this.btnDistributor.IconZoom = 90D;
            this.btnDistributor.IsTab = false;
            this.btnDistributor.Location = new System.Drawing.Point(0, 550);
            this.btnDistributor.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDistributor.Name = "btnDistributor";
            this.btnDistributor.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnDistributor.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnDistributor.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnDistributor.selected = false;
            this.btnDistributor.Size = new System.Drawing.Size(362, 74);
            this.btnDistributor.TabIndex = 52;
            this.btnDistributor.Text = "Distributor";
            this.btnDistributor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDistributor.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnDistributor.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDistributor.Click += new System.EventHandler(this.btnDistributor_Click);
            // 
            // btnPO
            // 
            this.btnPO.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnPO.BackColor = System.Drawing.Color.RosyBrown;
            this.btnPO.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPO.BorderRadius = 0;
            this.btnPO.ButtonText = "Purchasing Order";
            this.btnPO.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPO.DisabledColor = System.Drawing.Color.Black;
            this.btnPO.Iconcolor = System.Drawing.Color.Transparent;
            this.btnPO.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_checkout_30px_2;
            this.btnPO.Iconimage_right = null;
            this.btnPO.Iconimage_right_Selected = null;
            this.btnPO.Iconimage_Selected = null;
            this.btnPO.IconMarginLeft = 0;
            this.btnPO.IconMarginRight = 0;
            this.btnPO.IconRightVisible = true;
            this.btnPO.IconRightZoom = 0D;
            this.btnPO.IconVisible = true;
            this.btnPO.IconZoom = 90D;
            this.btnPO.IsTab = false;
            this.btnPO.Location = new System.Drawing.Point(0, 617);
            this.btnPO.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.btnPO.Name = "btnPO";
            this.btnPO.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnPO.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnPO.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnPO.selected = false;
            this.btnPO.Size = new System.Drawing.Size(362, 74);
            this.btnPO.TabIndex = 51;
            this.btnPO.Text = "Purchasing Order";
            this.btnPO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnPO.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnPO.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPO.Click += new System.EventHandler(this.btnPO_Click);
            // 
            // btnJenisProduk
            // 
            this.btnJenisProduk.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnJenisProduk.BackColor = System.Drawing.Color.RosyBrown;
            this.btnJenisProduk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnJenisProduk.BorderRadius = 0;
            this.btnJenisProduk.ButtonText = "Jenis Product";
            this.btnJenisProduk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnJenisProduk.DisabledColor = System.Drawing.Color.Black;
            this.btnJenisProduk.Iconcolor = System.Drawing.Color.Transparent;
            this.btnJenisProduk.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_tasks_30px;
            this.btnJenisProduk.Iconimage_right = null;
            this.btnJenisProduk.Iconimage_right_Selected = null;
            this.btnJenisProduk.Iconimage_Selected = null;
            this.btnJenisProduk.IconMarginLeft = 0;
            this.btnJenisProduk.IconMarginRight = 0;
            this.btnJenisProduk.IconRightVisible = true;
            this.btnJenisProduk.IconRightZoom = 0D;
            this.btnJenisProduk.IconVisible = true;
            this.btnJenisProduk.IconZoom = 90D;
            this.btnJenisProduk.IsTab = false;
            this.btnJenisProduk.Location = new System.Drawing.Point(1, 484);
            this.btnJenisProduk.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnJenisProduk.Name = "btnJenisProduk";
            this.btnJenisProduk.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnJenisProduk.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnJenisProduk.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnJenisProduk.selected = false;
            this.btnJenisProduk.Size = new System.Drawing.Size(362, 74);
            this.btnJenisProduk.TabIndex = 51;
            this.btnJenisProduk.Text = "Jenis Product";
            this.btnJenisProduk.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnJenisProduk.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnJenisProduk.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJenisProduk.Click += new System.EventHandler(this.btnJenisProduk_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnLogout.BackColor = System.Drawing.Color.RosyBrown;
            this.btnLogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLogout.BorderRadius = 0;
            this.btnLogout.ButtonText = "Logout";
            this.btnLogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogout.DisabledColor = System.Drawing.Color.Black;
            this.btnLogout.Iconcolor = System.Drawing.Color.Transparent;
            this.btnLogout.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_exit_30px;
            this.btnLogout.Iconimage_right = null;
            this.btnLogout.Iconimage_right_Selected = null;
            this.btnLogout.Iconimage_Selected = null;
            this.btnLogout.IconMarginLeft = 0;
            this.btnLogout.IconMarginRight = 0;
            this.btnLogout.IconRightVisible = true;
            this.btnLogout.IconRightZoom = 0D;
            this.btnLogout.IconVisible = true;
            this.btnLogout.IconZoom = 90D;
            this.btnLogout.IsTab = false;
            this.btnLogout.Location = new System.Drawing.Point(1, 812);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnLogout.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnLogout.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnLogout.selected = false;
            this.btnLogout.Size = new System.Drawing.Size(362, 74);
            this.btnLogout.TabIndex = 7;
            this.btnLogout.Text = "Logout";
            this.btnLogout.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnLogout.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnLogout.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnProduk
            // 
            this.btnProduk.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnProduk.BackColor = System.Drawing.Color.RosyBrown;
            this.btnProduk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnProduk.BorderRadius = 0;
            this.btnProduk.ButtonText = "Product";
            this.btnProduk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProduk.DisabledColor = System.Drawing.Color.Black;
            this.btnProduk.Iconcolor = System.Drawing.Color.Transparent;
            this.btnProduk.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_shopping_basket_30px;
            this.btnProduk.Iconimage_right = null;
            this.btnProduk.Iconimage_right_Selected = null;
            this.btnProduk.Iconimage_Selected = null;
            this.btnProduk.IconMarginLeft = 0;
            this.btnProduk.IconMarginRight = 0;
            this.btnProduk.IconRightVisible = true;
            this.btnProduk.IconRightZoom = 0D;
            this.btnProduk.IconVisible = true;
            this.btnProduk.IconZoom = 90D;
            this.btnProduk.IsTab = false;
            this.btnProduk.Location = new System.Drawing.Point(1, 421);
            this.btnProduk.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnProduk.Name = "btnProduk";
            this.btnProduk.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnProduk.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnProduk.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnProduk.selected = false;
            this.btnProduk.Size = new System.Drawing.Size(362, 74);
            this.btnProduk.TabIndex = 15;
            this.btnProduk.Text = "Product";
            this.btnProduk.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnProduk.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnProduk.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProduk.Click += new System.EventHandler(this.btnProduk_Click);
            // 
            // btnMember
            // 
            this.btnMember.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnMember.BackColor = System.Drawing.Color.RosyBrown;
            this.btnMember.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMember.BorderRadius = 0;
            this.btnMember.ButtonText = "Member";
            this.btnMember.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMember.DisabledColor = System.Drawing.Color.Black;
            this.btnMember.Iconcolor = System.Drawing.Color.Transparent;
            this.btnMember.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_name_tag_64;
            this.btnMember.Iconimage_right = null;
            this.btnMember.Iconimage_right_Selected = null;
            this.btnMember.Iconimage_Selected = null;
            this.btnMember.IconMarginLeft = 0;
            this.btnMember.IconMarginRight = 0;
            this.btnMember.IconRightVisible = true;
            this.btnMember.IconRightZoom = 0D;
            this.btnMember.IconVisible = true;
            this.btnMember.IconZoom = 90D;
            this.btnMember.IsTab = false;
            this.btnMember.Location = new System.Drawing.Point(1, 355);
            this.btnMember.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnMember.Name = "btnMember";
            this.btnMember.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnMember.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnMember.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnMember.selected = false;
            this.btnMember.Size = new System.Drawing.Size(362, 76);
            this.btnMember.TabIndex = 14;
            this.btnMember.Text = "Member";
            this.btnMember.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnMember.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnMember.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMember.Click += new System.EventHandler(this.btnMember_Click);
            // 
            // btnPegawai
            // 
            this.btnPegawai.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnPegawai.BackColor = System.Drawing.Color.RosyBrown;
            this.btnPegawai.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPegawai.BorderRadius = 0;
            this.btnPegawai.ButtonText = "Employee";
            this.btnPegawai.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPegawai.DisabledColor = System.Drawing.Color.Black;
            this.btnPegawai.Iconcolor = System.Drawing.Color.Transparent;
            this.btnPegawai.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_exit_30px;
            this.btnPegawai.Iconimage_right = null;
            this.btnPegawai.Iconimage_right_Selected = null;
            this.btnPegawai.Iconimage_Selected = null;
            this.btnPegawai.IconMarginLeft = 0;
            this.btnPegawai.IconMarginRight = 0;
            this.btnPegawai.IconRightVisible = true;
            this.btnPegawai.IconRightZoom = 0D;
            this.btnPegawai.IconVisible = true;
            this.btnPegawai.IconZoom = 90D;
            this.btnPegawai.IsTab = false;
            this.btnPegawai.Location = new System.Drawing.Point(0, 290);
            this.btnPegawai.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPegawai.Name = "btnPegawai";
            this.btnPegawai.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnPegawai.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnPegawai.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnPegawai.selected = false;
            this.btnPegawai.Size = new System.Drawing.Size(362, 75);
            this.btnPegawai.TabIndex = 13;
            this.btnPegawai.Text = "Employee";
            this.btnPegawai.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnPegawai.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnPegawai.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPegawai.Click += new System.EventHandler(this.btnPegawai_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label1.Location = new System.Drawing.Point(13, 951);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(324, 19);
            this.label1.TabIndex = 12;
            this.label1.Text = "Bilqis Tsaabitah && Ramadhan Dewantara";
            // 
            // btnTtgAplikasi
            // 
            this.btnTtgAplikasi.AutoSize = true;
            this.btnTtgAplikasi.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTtgAplikasi.ForeColor = System.Drawing.Color.SaddleBrown;
            this.btnTtgAplikasi.Location = new System.Drawing.Point(97, 914);
            this.btnTtgAplikasi.Name = "btnTtgAplikasi";
            this.btnTtgAplikasi.Size = new System.Drawing.Size(153, 22);
            this.btnTtgAplikasi.TabIndex = 4;
            this.btnTtgAplikasi.Text = "Tentang Aplikasi";
            this.btnTtgAplikasi.Click += new System.EventHandler(this.btnTtgAplikasi_Click);
            // 
            // btnDashboard
            // 
            this.btnDashboard.Activecolor = System.Drawing.Color.RosyBrown;
            this.btnDashboard.BackColor = System.Drawing.Color.RosyBrown;
            this.btnDashboard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDashboard.BorderRadius = 0;
            this.btnDashboard.ButtonText = "Dashboard";
            this.btnDashboard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDashboard.DisabledColor = System.Drawing.Color.Black;
            this.btnDashboard.Iconcolor = System.Drawing.Color.Transparent;
            this.btnDashboard.Iconimage = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_home_30px_1;
            this.btnDashboard.Iconimage_right = null;
            this.btnDashboard.Iconimage_right_Selected = null;
            this.btnDashboard.Iconimage_Selected = null;
            this.btnDashboard.IconMarginLeft = 0;
            this.btnDashboard.IconMarginRight = 0;
            this.btnDashboard.IconRightVisible = true;
            this.btnDashboard.IconRightZoom = 0D;
            this.btnDashboard.IconVisible = true;
            this.btnDashboard.IconZoom = 90D;
            this.btnDashboard.IsTab = false;
            this.btnDashboard.Location = new System.Drawing.Point(4, 227);
            this.btnDashboard.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Normalcolor = System.Drawing.Color.RosyBrown;
            this.btnDashboard.OnHovercolor = System.Drawing.Color.MistyRose;
            this.btnDashboard.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnDashboard.selected = false;
            this.btnDashboard.Size = new System.Drawing.Size(362, 74);
            this.btnDashboard.TabIndex = 1;
            this.btnDashboard.Text = "Dashboard";
            this.btnDashboard.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDashboard.Textcolor = System.Drawing.Color.SaddleBrown;
            this.btnDashboard.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.Kebawah;
            this.pictureBox1.Location = new System.Drawing.Point(-74, -99);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(477, 474);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Tan;
            this.panel2.Controls.Add(this.BtnClose);
            this.panel2.Controls.Add(this.bunifuImageButton1);
            this.panel2.Controls.Add(this.bunifuCustomLabel1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1898, 49);
            this.panel2.TabIndex = 47;
            // 
            // BtnClose
            // 
            this.BtnClose.BackColor = System.Drawing.Color.Transparent;
            this.BtnClose.Image = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_delete_30px;
            this.BtnClose.ImageActive = null;
            this.BtnClose.Location = new System.Drawing.Point(1853, 0);
            this.BtnClose.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(45, 46);
            this.BtnClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BtnClose.TabIndex = 51;
            this.BtnClose.TabStop = false;
            this.BtnClose.Zoom = 10;
            this.BtnClose.Click += new System.EventHandler(this.BtnClose_Click);
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton1.Image = global::Project_PRG2_Kel12_RakisComputer.Properties.Resources.icons8_reboot_30px;
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(1749, 0);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(66, 49);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton1.TabIndex = 46;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            this.bunifuImageButton1.Click += new System.EventHandler(this.bunifuImageButton1_Click);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.SaddleBrown;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(11, 9);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(737, 28);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "Aplikasi Rakis Computer - Halaman Admin - Master Distributor";
            // 
            // bunifuCustomDataGrid1
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuCustomDataGrid1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.bunifuCustomDataGrid1.AutoGenerateColumns = false;
            this.bunifuCustomDataGrid1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.bunifuCustomDataGrid1.BackgroundColor = System.Drawing.Color.MistyRose;
            this.bunifuCustomDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuCustomDataGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.RosyBrown;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.MistyRose;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuCustomDataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.bunifuCustomDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bunifuCustomDataGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDistributorDataGridViewTextBoxColumn,
            this.namaDataGridViewTextBoxColumn,
            this.alamatDataGridViewTextBoxColumn,
            this.nohpDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn});
            this.bunifuCustomDataGrid1.DataSource = this.distributorBindingSource;
            this.bunifuCustomDataGrid1.DoubleBuffered = true;
            this.bunifuCustomDataGrid1.EnableHeadersVisualStyles = false;
            this.bunifuCustomDataGrid1.GridColor = System.Drawing.Color.MistyRose;
            this.bunifuCustomDataGrid1.HeaderBgColor = System.Drawing.Color.RosyBrown;
            this.bunifuCustomDataGrid1.HeaderForeColor = System.Drawing.Color.MistyRose;
            this.bunifuCustomDataGrid1.Location = new System.Drawing.Point(547, 205);
            this.bunifuCustomDataGrid1.Name = "bunifuCustomDataGrid1";
            this.bunifuCustomDataGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.bunifuCustomDataGrid1.RowTemplate.Height = 28;
            this.bunifuCustomDataGrid1.Size = new System.Drawing.Size(1289, 667);
            this.bunifuCustomDataGrid1.TabIndex = 49;
            // 
            // idDistributorDataGridViewTextBoxColumn
            // 
            this.idDistributorDataGridViewTextBoxColumn.DataPropertyName = "Id_Distributor";
            this.idDistributorDataGridViewTextBoxColumn.HeaderText = "Id_Distributor";
            this.idDistributorDataGridViewTextBoxColumn.Name = "idDistributorDataGridViewTextBoxColumn";
            // 
            // namaDataGridViewTextBoxColumn
            // 
            this.namaDataGridViewTextBoxColumn.DataPropertyName = "Nama";
            this.namaDataGridViewTextBoxColumn.HeaderText = "Nama";
            this.namaDataGridViewTextBoxColumn.Name = "namaDataGridViewTextBoxColumn";
            // 
            // alamatDataGridViewTextBoxColumn
            // 
            this.alamatDataGridViewTextBoxColumn.DataPropertyName = "alamat";
            this.alamatDataGridViewTextBoxColumn.HeaderText = "alamat";
            this.alamatDataGridViewTextBoxColumn.Name = "alamatDataGridViewTextBoxColumn";
            // 
            // nohpDataGridViewTextBoxColumn
            // 
            this.nohpDataGridViewTextBoxColumn.DataPropertyName = "no_hp";
            this.nohpDataGridViewTextBoxColumn.HeaderText = "no_hp";
            this.nohpDataGridViewTextBoxColumn.Name = "nohpDataGridViewTextBoxColumn";
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "email";
            this.emailDataGridViewTextBoxColumn.HeaderText = "email";
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            // 
            // distributorBindingSource
            // 
            this.distributorBindingSource.DataMember = "Distributor";
            this.distributorBindingSource.DataSource = this.db_Rakis_computerrDataSet;
            // 
            // db_Rakis_computerrDataSet
            // 
            this.db_Rakis_computerrDataSet.DataSetName = "db_Rakis_computerrDataSet";
            this.db_Rakis_computerrDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label2.Location = new System.Drawing.Point(972, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(586, 56);
            this.label2.TabIndex = 48;
            this.label2.Text = "TABEL DATA DISTRIBUTOR";
            // 
            // btnUbahData
            // 
            this.btnUbahData.ActiveBorderThickness = 1;
            this.btnUbahData.ActiveCornerRadius = 20;
            this.btnUbahData.ActiveFillColor = System.Drawing.Color.Transparent;
            this.btnUbahData.ActiveForecolor = System.Drawing.Color.RosyBrown;
            this.btnUbahData.ActiveLineColor = System.Drawing.Color.Black;
            this.btnUbahData.BackColor = System.Drawing.Color.MistyRose;
            this.btnUbahData.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUbahData.BackgroundImage")));
            this.btnUbahData.ButtonText = "Ubah Data";
            this.btnUbahData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUbahData.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUbahData.ForeColor = System.Drawing.Color.SaddleBrown;
            this.btnUbahData.IdleBorderThickness = 1;
            this.btnUbahData.IdleCornerRadius = 20;
            this.btnUbahData.IdleFillColor = System.Drawing.Color.MistyRose;
            this.btnUbahData.IdleForecolor = System.Drawing.Color.SaddleBrown;
            this.btnUbahData.IdleLineColor = System.Drawing.Color.SaddleBrown;
            this.btnUbahData.Location = new System.Drawing.Point(1315, 880);
            this.btnUbahData.Margin = new System.Windows.Forms.Padding(5);
            this.btnUbahData.Name = "btnUbahData";
            this.btnUbahData.Size = new System.Drawing.Size(243, 63);
            this.btnUbahData.TabIndex = 50;
            this.btnUbahData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnUbahData.Click += new System.EventHandler(this.btnUbahData_Click);
            // 
            // btnTmbhData
            // 
            this.btnTmbhData.ActiveBorderThickness = 1;
            this.btnTmbhData.ActiveCornerRadius = 20;
            this.btnTmbhData.ActiveFillColor = System.Drawing.Color.Transparent;
            this.btnTmbhData.ActiveForecolor = System.Drawing.Color.RosyBrown;
            this.btnTmbhData.ActiveLineColor = System.Drawing.Color.Black;
            this.btnTmbhData.BackColor = System.Drawing.Color.MistyRose;
            this.btnTmbhData.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnTmbhData.BackgroundImage")));
            this.btnTmbhData.ButtonText = "Tambah Data";
            this.btnTmbhData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTmbhData.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTmbhData.ForeColor = System.Drawing.Color.SaddleBrown;
            this.btnTmbhData.IdleBorderThickness = 1;
            this.btnTmbhData.IdleCornerRadius = 20;
            this.btnTmbhData.IdleFillColor = System.Drawing.Color.MistyRose;
            this.btnTmbhData.IdleForecolor = System.Drawing.Color.SaddleBrown;
            this.btnTmbhData.IdleLineColor = System.Drawing.Color.SaddleBrown;
            this.btnTmbhData.Location = new System.Drawing.Point(856, 880);
            this.btnTmbhData.Margin = new System.Windows.Forms.Padding(5);
            this.btnTmbhData.Name = "btnTmbhData";
            this.btnTmbhData.Size = new System.Drawing.Size(243, 63);
            this.btnTmbhData.TabIndex = 45;
            this.btnTmbhData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnTmbhData.Click += new System.EventHandler(this.btnTmbhData_Click);
            // 
            // distributorTableAdapter
            // 
            this.distributorTableAdapter.ClearBeforeFill = true;
            // 
            // MasterDistributor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(1898, 1024);
            this.Controls.Add(this.btnUbahData);
            this.Controls.Add(this.btnTmbhData);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.bunifuCustomDataGrid1);
            this.Controls.Add(this.label2);
            this.Name = "MasterDistributor";
            this.Text = "MasterDistributor";
            this.Load += new System.EventHandler(this.MasterDistributor_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BtnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.distributorBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.db_Rakis_computerrDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label btnTtgAplikasi;
        private Bunifu.Framework.UI.BunifuFlatButton btnLogout;
        private Bunifu.Framework.UI.BunifuFlatButton btnDashboard;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomDataGrid bunifuCustomDataGrid1;
        private System.Windows.Forms.Label label2;
        private Bunifu.Framework.UI.BunifuThinButton2 btnTmbhData;
        private Bunifu.Framework.UI.BunifuThinButton2 btnUbahData;
        private db_Rakis_computerrDataSet db_Rakis_computerrDataSet;
        private System.Windows.Forms.BindingSource distributorBindingSource;
        private db_Rakis_computerrDataSetTableAdapters.DistributorTableAdapter distributorTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDistributorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn namaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn alamatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nohpDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private Bunifu.Framework.UI.BunifuImageButton BtnClose;
        private Bunifu.Framework.UI.BunifuFlatButton btnPegawai;
        private Bunifu.Framework.UI.BunifuFlatButton btnMember;
        private Bunifu.Framework.UI.BunifuFlatButton btnProduk;
        private Bunifu.Framework.UI.BunifuFlatButton btnJenisProduk;
        private Bunifu.Framework.UI.BunifuFlatButton btnPO;
        private Bunifu.Framework.UI.BunifuFlatButton btnDistributor;
        private Bunifu.Framework.UI.BunifuFlatButton btnService;
        private Bunifu.Framework.UI.BunifuFlatButton btnPaket;
    }
}